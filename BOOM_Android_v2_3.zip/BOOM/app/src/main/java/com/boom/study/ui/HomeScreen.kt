package com.boom.study.ui

import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.boom.study.data.StudyTask
import com.boom.study.viewmodel.Overview
import java.time.LocalTime

private val lines = listOf(
    "Small steps every day beat big plans someday.",
    "Future you is watching. Make them proud.",
    "Focus for 25 minutes. The rest can wait.",
    "Revision turns knowing into remembering.",
    "You don't need motivation. You need the next chapter.",
    "One chapter today is one step closer to the paper.",
    "Consistency is your unfair advantage.",
    "Tough day? Do 15 minutes, then decide.",
    "Boards are a sprint made of many small days.",
    "Rest is part of the plan. Sleep counts as revision."
)

private fun phaseOf(daysLeft: Long) = when {
    daysLeft > 120 -> "Build phase"
    daysLeft > 60 -> "Practice phase"
    daysLeft > 30 -> "Revision sprint"
    daysLeft > 0 -> "Final stretch"
    else -> "Exam time"
}

private fun greeting(): String {
    val h = LocalTime.now().hour
    return when {
        h < 5 -> "Burning the midnight oil"
        h < 12 -> "Good morning"
        h < 17 -> "Good afternoon"
        else -> "Good evening"
    }
}

@Composable
fun HomeScreen(
    overview: Overview?,
    subjectName: (Long?) -> String,
    onToggleTask: (StudyTask) -> Unit,
    onNavigate: (String) -> Unit
) {
    if (overview == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = MaterialTheme.colorScheme.primary) }
        return
    }
    val o = overview
    val haptic = LocalHapticFeedback.current
    var startCount by remember { mutableIntStateOf(0) }
    LaunchedEffect(o.daysLeft) { startCount = o.daysLeft.toInt().coerceAtLeast(0) }
    val shownDays by animateIntAsState(startCount, tween(1100), label = "days")
    val quote = lines[(o.today % lines.size).toInt().coerceAtLeast(0)]

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("BOOM", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onBackground)
                        Text(".", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
                    }
                    Text("${greeting()} · ${fmtDate(o.today)}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { onNavigate("settings") }) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            Reveal(0) {
                Surface(shape = RoundedCornerShape(26.dp), color = Color.Transparent, shadowElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
                    Column(
                        Modifier.background(Brush.linearGradient(listOf(lerp(MaterialTheme.colorScheme.primary, Color.White, 0.22f), MaterialTheme.colorScheme.primary))).padding(20.dp)
                    ) {
                        val ink = MaterialTheme.colorScheme.onPrimary
                        Surface(shape = RoundedCornerShape(50), color = ink.copy(alpha = 0.14f)) {
                            Text(
                                phaseOf(o.daysLeft).uppercase(), color = ink, style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                if (o.daysLeft > 0) "$shownDays" else if (o.daysLeft == 0L) "Today" else "Done",
                                fontSize = 66.sp, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, color = ink
                            )
                            if (o.daysLeft > 0) {
                                Spacer(Modifier.width(8.dp))
                                Text(if (o.daysLeft == 1L) "day to go" else "days to go", color = ink, modifier = Modifier.padding(bottom = 14.dp), fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Text("CBSE Boards · ${fmtDateLong(o.examEpochDay)}", color = ink, style = MaterialTheme.typography.bodyMedium)
                        if (o.daysLeft > 7) Text("${o.daysLeft / 7} weeks and ${o.daysLeft % 7} days left", color = ink.copy(alpha = 0.75f), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        item {
            Reveal(1) {
                BoomCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocalFireDepartment, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(6.dp))
                        SectionLabel("This week", Modifier.weight(1f))
                        Text("${o.streak} day streak · best ${o.bestStreak}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        o.activeLast7.forEachIndexed { i, on ->
                            val isToday = i == o.activeLast7.lastIndex
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    Modifier.size(32.dp)
                                        .background(if (on) MaterialTheme.colorScheme.primary else Color.Transparent, CircleShape)
                                        .border(if (isToday) 2.dp else 1.dp, if (on) MaterialTheme.colorScheme.primary else if (isToday) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) { if (on) Icon(Icons.Default.Check, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onPrimary) }
                                Spacer(Modifier.height(4.dp))
                                Text(o.dayLabels.getOrElse(i) { "" }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
        item { Reveal(2) { LevelCard(o) } }
        item {
            Reveal(3) {
                BoomCard {
                    SectionLabel("Today's targets")
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Ring(o.tasksDoneToday.toFloat() / maxOf(o.taskGoal, 1), 88.dp, 10.dp, MaterialTheme.colorScheme.primary) {
                            Text("${o.tasksDoneToday}/${o.taskGoal}", fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Tasks completed", fontWeight = FontWeight.SemiBold)
                            Text("${o.tasksToday.size} planned for today", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(10.dp))
                            Text("Focus ${fmtDuration(o.focusTodayMin)} of ${fmtDuration(o.focusGoalMin)}", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(6.dp))
                            BoomProgress(o.focusTodayMin.toFloat() / maxOf(o.focusGoalMin, 1), color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Syllabus ${(o.syllabusFraction * 100).toInt()}% · ${o.doneChapters}/${o.totalChapters} chapters", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    BoomProgress(o.syllabusFraction, color = MaterialTheme.colorScheme.tertiary)
                }
            }
        }
        item {
            Reveal(4) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    QuickAction(Icons.Default.Add, "Add task") { onNavigate("planner?add=true") }
                    QuickAction(Icons.Default.Timer, "Focus") { onNavigate("focus") }
                    QuickAction(Icons.Default.Autorenew, "Revise") { onNavigate("revision") }
                    QuickAction(Icons.Default.MenuBook, "Syllabus") { onNavigate("syllabus") }
                    QuickAction(Icons.Default.BarChart, "Stats") { onNavigate("stats") }
                }
            }
        }
        item {
            BoomCard(container = MaterialTheme.colorScheme.surfaceVariant) {
                Text(quote, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Medium), color = MaterialTheme.colorScheme.onSurface)
                Text("DAILY BOOST", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp))
            }
        }
        if (o.overdueTasks > 0) {
            item {
                BoomCard(onClick = { onNavigate("planner") }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Schedule, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Text("${o.overdueTasks} unfinished task${if (o.overdueTasks == 1) "" else "s"} from earlier days. Tap to reschedule.", Modifier.weight(1f))
                    }
                }
            }
        }
        item { SectionLabel("Today's plan", Modifier.padding(top = 4.dp)) }
        if (o.tasksToday.isEmpty()) {
            item { BoomCard { Text("Nothing planned yet. Tap Add task to set your first target.", color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        } else {
            items(o.tasksToday.take(6), key = { it.id }) { t ->
                TaskRow(t, subjectName(t.subjectId), onToggle = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onToggleTask(t)
                })
            }
            if (o.tasksToday.size > 6) item { TextButton(onClick = { onNavigate("planner") }) { Text("See all ${o.tasksToday.size} tasks") } }
        }
    }
}

@Composable
private fun QuickAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick).padding(4.dp)) {
        Surface(
            shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 3.dp, modifier = Modifier.size(54.dp),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
        ) {
            Box(contentAlignment = Alignment.Center) { Icon(icon, label, tint = MaterialTheme.colorScheme.primary) }
        }
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
