package com.boom.study.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.boom.study.data.Settings
import com.boom.study.notify.Notif
import com.boom.study.viewmodel.SettingsViewModel
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun SettingsScreen(vm: SettingsViewModel, onBack: () -> Unit, onTimetable: () -> Unit) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsState()

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun ensurePermission() {
        if (Build.VERSION.SDK_INT >= 33 && !Notif.canPost(ctx)) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> if (uri != null) vm.exportTo(uri) }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importFrom(uri) }
    var confirmRestore by remember { mutableStateOf(false) }
    var goalMin by remember(s.dailyFocusGoalMin) { mutableFloatStateOf(s.dailyFocusGoalMin.toFloat()) }
    var goalTasks by remember(s.dailyTaskGoal) { mutableFloatStateOf(s.dailyTaskGoal.toFloat()) }

    fun toggle(on: Boolean, change: (Settings) -> Settings) {
        if (on) ensurePermission()
        vm.update(change)
    }

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                Text("Settings", style = MaterialTheme.typography.headlineMedium)
            }
        }
        item {
            BoomCard {
                SectionLabel("Theme")
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    themeOptions.forEach { (key, label) ->
                        FilterChip(selected = s.theme == key, onClick = { vm.update { it.copy(theme = key) } }, label = { Text(label, maxLines = 1) })
                    }
                }
            }
        }
        item {
            BoomCard {
                SectionLabel("Study goals")
                Spacer(Modifier.height(8.dp))
                Text("Daily focus goal: ${fmtDuration(goalMin.toInt())}", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = goalMin, onValueChange = { goalMin = it }, valueRange = 30f..600f, steps = 18,
                    onValueChangeFinished = { vm.update { it.copy(dailyFocusGoalMin = goalMin.toInt()) } }
                )
                Text("Daily task goal: ${goalTasks.toInt()} tasks", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = goalTasks, onValueChange = { goalTasks = it }, valueRange = 1f..15f, steps = 13,
                    onValueChangeFinished = { vm.update { it.copy(dailyTaskGoal = goalTasks.toInt()) } }
                )
                OutlinedButton(onClick = { pickDate(ctx, s.examEpochDay) { d -> vm.update { it.copy(examEpochDay = d) } } }, modifier = Modifier.fillMaxWidth()) {
                    Text("Exam date: ${LocalDate.ofEpochDay(s.examEpochDay).format(DateTimeFormatter.ofPattern("d MMM yyyy"))}")
                }
            }
        }
        item {
            BoomCard {
                SectionLabel("Timetable")
                Spacer(Modifier.height(6.dp))
                Text("Edit your repeating weekly routine.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = onTimetable) { Text("Open timetable editor") }
            }
        }
        item {
            BoomCard {
                SectionLabel("Notifications (all optional)")
                SwitchRow("Upcoming study sessions", s.notifSession) { on -> toggle(on) { it.copy(notifSession = on) } }
                SwitchRow("Pending tasks (evening)", s.notifPending) { on -> toggle(on) { it.copy(notifPending = on) } }
                SwitchRow("Revision reminders (morning)", s.notifRevision) { on -> toggle(on) { it.copy(notifRevision = on) } }
                SwitchRow("Daily study goal", s.notifDailyGoal) { on -> toggle(on) { it.copy(notifDailyGoal = on) } }
                if (s.notifDailyGoal) {
                    OutlinedButton(onClick = {
                        android.app.TimePickerDialog(ctx, { _, h, _ -> vm.update { it.copy(goalReminderHour = h) } }, s.goalReminderHour, 0, false).show()
                    }) { Text("Goal reminder at ${fmtTime(s.goalReminderHour * 60)}") }
                }
                SwitchRow("Break reminder after focus sessions", s.breakReminder) { on -> toggle(on) { it.copy(breakReminder = on) } }
                if (s.breakReminder) {
                    Text("Break length: ${s.breakMin} min", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 10, 15).forEach { m -> FilterChip(selected = s.breakMin == m, onClick = { vm.update { it.copy(breakMin = m) } }, label = { Text("$m min") }) }
                    }
                }
                Text(
                    "Reminders are checked about every 15 minutes, so their timing is approximate. Battery-saver modes can delay them.",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
        item {
            BoomCard {
                SectionLabel("Backup & restore")
                Spacer(Modifier.height(6.dp))
                Text("Everything is stored only on this phone. Save a backup file before changing phones or reinstalling.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { exportLauncher.launch("boom-backup-${LocalDate.now()}.json") }) { Text("Back up") }
                    OutlinedButton(onClick = { confirmRestore = true }) { Text("Restore") }
                }
            }
        }
        item {
            BoomCard {
                SectionLabel("About")
                Spacer(Modifier.height(6.dp))
                Text("BOOM 2.3 · No account, no ads, no internet permission.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Preloaded chapters are a starting point. Check them against your school's syllabus.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
    if (confirmRestore) {
        AlertDialog(
            onDismissRequest = { confirmRestore = false },
            title = { Text("Restore from backup?") },
            text = { Text("This replaces all current data in BOOM with the contents of the backup file.") },
            confirmButton = { TextButton(onClick = { confirmRestore = false; importLauncher.launch(arrayOf("*/*")) }) { Text("Choose file") } },
            dismissButton = { TextButton(onClick = { confirmRestore = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
