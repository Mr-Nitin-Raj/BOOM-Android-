package com.boom.study.data

import androidx.room.withTransaction
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.first
import java.time.LocalDate

class BoomRepository(private val db: BoomDatabase, val settings: SettingsStore) {
    private val dao = db.dao()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    /** User-visible error/info messages (shown as toasts). */
    val messages: SharedFlow<String> = _messages

    val subjects = dao.subjects()
    val chapters = dao.chapters()
    val tasks = dao.tasks()
    val revisions = dao.revisions()
    val sessions = dao.sessions()
    val timetable = dao.timetable()

    fun notify(msg: String) { _messages.tryEmit(msg) }

    private suspend fun guard(what: String, block: suspend () -> Unit) {
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _messages.tryEmit("$what failed: ${e.message ?: "unexpected error"}")
        }
    }

    suspend fun seedIfNeeded() = guard("Loading starter data") {
        if (!settings.seeded && dao.subjectCount() == 0) {
            db.withTransaction { Seed.insertInto(dao) }
        }
        settings.seeded = true
    }

    private fun today() = LocalDate.now().toEpochDay()

    // ---- Subjects & chapters ----
    suspend fun addSubject(name: String, color: Long) = guard("Add subject") {
        dao.insertSubject(Subject(name = name.trim(), color = color, sortOrder = dao.subjectCount() + 100, custom = true))
    }
    suspend fun renameSubject(s: Subject, name: String) = guard("Rename subject") { dao.updateSubject(s.copy(name = name.trim())) }
    suspend fun deleteSubject(s: Subject) = guard("Delete subject") { dao.deleteSubject(s) }

    suspend fun addChapter(subjectId: Long, name: String) = guard("Add chapter") {
        dao.insertChapter(Chapter(subjectId = subjectId, name = name.trim(), sortOrder = dao.maxChapterOrder(subjectId) + 1))
    }
    suspend fun renameChapter(c: Chapter, name: String) = guard("Edit chapter") { dao.updateChapter(c.copy(name = name.trim())) }
    suspend fun deleteChapter(c: Chapter) = guard("Delete chapter") { dao.deleteChapter(c) }

    suspend fun setChapterStatus(c: Chapter, status: ChapterStatus) = guard("Update chapter") {
        dao.updateChapter(c.copy(status = status.name))
        if (status.isDone && dao.revisionCountForChapter(c.id) == 0) {
            val exam = settings.flow.value.examEpochDay
            val t = today()
            fun cap(d: Long) = if (exam > t + 1) maxOf(t + 1, minOf(d, exam - 1)) else d
            listOf(RevisionType.FIRST to 3L, RevisionType.SECOND to 10L, RevisionType.FINAL to 30L).forEach { (type, off) ->
                dao.insertRevision(RevisionItem(subjectId = c.subjectId, chapterId = c.id, type = type.name, dueDate = cap(t + off)))
            }
        }
    }

    // ---- Tasks ----
    suspend fun saveTask(t: StudyTask) = guard("Save task") {
        if (t.id == 0L) dao.insertTask(t) else dao.updateTask(t)
    }
    suspend fun setTaskDone(t: StudyTask, done: Boolean) = guard("Update task") {
        dao.updateTask(t.copy(done = done, completedAt = if (done) System.currentTimeMillis() else null))
    }
    suspend fun moveTask(t: StudyTask, day: Long) = guard("Reschedule task") {
        dao.updateTask(t.copy(date = day, rescheduled = t.rescheduled + 1))
    }
    suspend fun moveOverdueToToday() = guard("Reschedule tasks") {
        val t = today()
        db.withTransaction { dao.overdueTasks(t).forEach { dao.updateTask(it.copy(date = t, rescheduled = it.rescheduled + 1)) } }
    }
    suspend fun deleteTask(t: StudyTask) = guard("Delete task") { dao.deleteTask(t) }

    // ---- Revisions ----
    suspend fun addRevision(r: RevisionItem) = guard("Add revision") { dao.insertRevision(r) }
    suspend fun setRevisionDone(r: RevisionItem, done: Boolean) = guard("Update revision") {
        dao.updateRevision(r.copy(done = done, doneAt = if (done) System.currentTimeMillis() else null))
    }
    suspend fun deleteRevision(r: RevisionItem) = guard("Delete revision") { dao.deleteRevision(r) }

    /** Spreads first/second/final revisions for completed chapters that have none yet. */
    suspend fun autoPlanRevisions(): Int {
        var planned = 0
        guard("Auto-plan revisions") {
            val t = today()
            val exam = settings.flow.value.examEpochDay
            val subjectsById = dao.subjects().first().associateBy { it.id }
            val pending = dao.chaptersOnce().filter {
                ChapterStatus.from(it.status).isDone && it.subjectId in subjectsById && dao.revisionCountForChapter(it.id) == 0
            }
            fun cap(d: Long) = if (exam > t + 1) maxOf(t + 1, minOf(d, exam - 1)) else d
            db.withTransaction {
                pending.forEachIndexed { i, c ->
                    val first = t + 1 + i / 3
                    val second = first + 12
                    val final = maxOf(second + 14, exam - 30 + i / 3)
                    listOf(RevisionType.FIRST to first, RevisionType.SECOND to second, RevisionType.FINAL to final).forEach { (type, d) ->
                        dao.insertRevision(RevisionItem(subjectId = c.subjectId, chapterId = c.id, type = type.name, dueDate = cap(d)))
                    }
                }
            }
            planned = pending.size
        }
        return planned
    }

    // ---- Focus sessions ----
    suspend fun addSession(s: FocusSession) = guard("Save focus session") { dao.insertSession(s) }
    suspend fun clearSessions() = guard("Clear history") { dao.wipeSessions() }

    // ---- Timetable ----
    suspend fun saveSlot(s: TimetableSlot) = guard("Save timetable slot") {
        if (s.id == 0L) dao.insertSlot(s) else dao.updateSlot(s)
    }
    suspend fun deleteSlot(s: TimetableSlot) = guard("Delete timetable slot") { dao.deleteSlot(s) }

    // ---- Backup / restore ----
    suspend fun exportJson(): String? {
        var out: String? = null
        guard("Backup") {
            out = BackupCodec.encode(
                Snapshot(
                    dao.subjects().first(), dao.chapters().first(), dao.tasks().first(), dao.revisions().first(),
                    dao.sessions().first(), dao.timetable().first(), settings.flow.value
                )
            )
        }
        return out
    }

    suspend fun importJson(json: String): Boolean {
        var ok = false
        guard("Restore") {
            val s = BackupCodec.decode(json)
            db.withTransaction {
                dao.wipeTasks(); dao.wipeRevisions(); dao.wipeChapters(); dao.wipeSubjects(); dao.wipeTimetable(); dao.wipeSessions()
                dao.putSubjects(s.subjects); dao.putChapters(s.chapters); dao.putTasks(s.tasks)
                dao.putRevisions(s.revisions); dao.putSessions(s.sessions); dao.putSlots(s.slots)
            }
            settings.update { s.settings }
            settings.seeded = true
            ok = true
        }
        return ok
    }
}
