package com.boom.study.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.boom.study.data.RevisionItem
import com.boom.study.data.RevisionType
import com.boom.study.viewmodel.RevisionViewModel
import java.time.LocalDate

@Composable
fun RevisionScreen(vm: RevisionViewModel, onBack: () -> Unit) {
    val revisions by vm.revisions.collectAsState()
    val subjects by vm.subjects.collectAsState()
    val chapters by vm.chapters.collectAsState()
    val today = LocalDate.now().toEpochDay()
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<RevisionItem?>(null) }
    var showDone by remember { mutableStateOf(false) }

    val valid = revisions.filter { r -> subjects.any { it.id == r.subjectId } }
    val pending = valid.filter { !it.done }.sortedBy { it.dueDate }
    val overdue = pending.filter { it.dueDate < today }
    val dueToday = pending.filter { it.dueDate == today }
    val upcoming = pending.filter { it.dueDate > today }
    val done = valid.filter { it.done }.sortedByDescending { it.doneAt ?: 0L }

    fun describe(r: RevisionItem): String {
        val subject = subjects.firstOrNull { it.id == r.subjectId }?.name ?: ""
        val chapter = chapters.firstOrNull { it.id == r.chapterId }?.name
        return listOfNotNull(subject.takeIf { it.isNotBlank() }, chapter).joinToString(" · ")
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                    Column {
                        Text("Revision", style = MaterialTheme.typography.headlineMedium)
                        Text("Spaced revision keeps chapters fresh", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item {
                BoomCard {
                    Row {
                        SectionLabel("Revision progress", Modifier.weight(1f))
                        Text("${done.size} / ${valid.size}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(8.dp))
                    BoomProgress(if (valid.isEmpty()) 0f else done.size.toFloat() / valid.size, color = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { vm.autoPlan() }) {
                        Icon(Icons.Default.Autorenew, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Auto-schedule for completed chapters")
                    }
                    Text(
                        "Creates first, second and final revisions for completed chapters. Chapters you mark Completed later are scheduled automatically.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
            if (pending.isEmpty()) item { EmptyState("Nothing pending. Add a revision or auto-schedule.") }
            revisionGroup("Overdue", overdue, today, ::describe, vm, { deleting = it })
            revisionGroup("Today", dueToday, today, ::describe, vm, { deleting = it })
            revisionGroup("Upcoming", upcoming, today, ::describe, vm, { deleting = it })
            if (done.isNotEmpty()) {
                item { TextButton(onClick = { showDone = !showDone }) { Text(if (showDone) "Hide completed (${done.size})" else "Show completed (${done.size})") } }
                if (showDone) revisionGroup(null, done, today, ::describe, vm, { deleting = it })
            }
        }
        ExtendedFloatingActionButton(
            onClick = { adding = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp),
            containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary,
            icon = { Icon(Icons.Default.Add, null) }, text = { Text("Schedule") }
        )
    }
    if (adding) RevisionDialog(subjects.map { it.id to it.name }, chapters.map { Triple(it.id, it.subjectId, it.name) }, today, { vm.add(it) }, { adding = false })
    deleting?.let { r -> ConfirmDialog("Delete revision?", "This revision item will be removed.", onConfirm = { vm.delete(r) }, onDismiss = { deleting = null }) }
}

private fun androidx.compose.foundation.lazy.LazyListScope.revisionGroup(
    title: String?, list: List<RevisionItem>, today: Long, describe: (RevisionItem) -> String,
    vm: RevisionViewModel, onDelete: (RevisionItem) -> Unit
) {
    if (list.isEmpty()) return
    if (title != null) item { SectionLabel("$title · ${list.size}", Modifier.padding(top = 6.dp)) }
    items(list, key = { it.id }) { r ->
        val late = !r.done && r.dueDate < today
        BoomCard(onClick = { vm.toggle(r) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (r.done) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, null,
                    tint = if (r.done) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.secondary
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        RevisionType.from(r.type).label, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Medium),
                        textDecoration = if (r.done) TextDecoration.LineThrough else null
                    )
                    val d = describe(r)
                    if (d.isNotBlank()) Text(d, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        (if (late) "Overdue · " else "") + fmtDate(r.dueDate), style = MaterialTheme.typography.bodyMedium,
                        color = if (late) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(onClick = { onDelete(r) }) { Icon(Icons.Default.Delete, "Delete revision", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
}

@Composable
private fun RevisionDialog(
    subjects: List<Pair<Long, String>>, chapters: List<Triple<Long, Long, String>>, today: Long,
    onSave: (RevisionItem) -> Unit, onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    var type by remember { mutableStateOf(RevisionType.FIRST) }
    var subjectId by remember { mutableStateOf(subjects.firstOrNull()?.first) }
    var chapterId by remember { mutableStateOf<Long?>(null) }
    var due by remember { mutableLongStateOf(today + 1) }
    val chapterOptions: List<Pair<String, Long?>> = listOf<Pair<String, Long?>>("Whole subject" to null) +
        chapters.filter { it.second == subjectId }.map { it.third to it.first }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Schedule revision") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DropdownField("Type", type.label, RevisionType.entries.map { it.label to it }, { type = it })
                DropdownField("Subject", subjects.firstOrNull { it.first == subjectId }?.second ?: "Choose", subjects.map { it.second to it.first }, { subjectId = it; chapterId = null })
                DropdownField("Chapter", chapters.firstOrNull { it.first == chapterId }?.third ?: "Whole subject", chapterOptions, { chapterId = it })
                OutlinedButton(onClick = { pickDate(ctx, due) { due = it } }, modifier = Modifier.fillMaxWidth()) { Text("Due: ${fmtDate(due)}") }
            }
        },
        confirmButton = {
            TextButton(enabled = subjectId != null, onClick = {
                onSave(RevisionItem(subjectId = subjectId!!, chapterId = chapterId, type = type.name, dueDate = due))
                onDismiss()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
