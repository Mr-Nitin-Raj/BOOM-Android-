package com.boom.study.data

/**
 * Preloaded tracker. Chapter names follow the standard CBSE Class 10 textbooks.
 * Statuses come from the progress shared in the earlier BOOM starter; verify against your school syllabus.
 */
object Seed {
    private class Spec(
        val name: String,
        val parentGroup: String?,
        val color: Long,
        val chapters: List<String>,
        val done: Set<Int> = emptySet(),
        val progress: Set<Int> = emptySet()
    )

    private val specs = listOf(
        Spec(
            "Science", null, 0xFFB9D68B,
            listOf(
                "Chemical Reactions and Equations", "Acids, Bases and Salts", "Metals and Non-metals",
                "Carbon and Its Compounds", "Light – Reflection and Refraction",
                "The Human Eye and the Colourful World", "Electricity", "Magnetic Effects of Electric Current",
                "Life Processes", "Control and Coordination", "How do Organisms Reproduce?",
                "Heredity", "Our Environment"
            ),
            done = setOf(0, 1, 2, 4, 5, 6, 7, 8, 9), progress = setOf(3)
        ),
        Spec(
            "Mathematics", null, 0xFFFF8547,
            listOf(
                "Real Numbers", "Polynomials", "Pair of Linear Equations in Two Variables", "Quadratic Equations",
                "Arithmetic Progressions", "Triangles", "Coordinate Geometry", "Introduction to Trigonometry",
                "Some Applications of Trigonometry", "Circles", "Areas Related to Circles",
                "Surface Areas and Volumes", "Statistics", "Probability"
            ),
            done = (0..13).toSet()
        ),
        Spec(
            "History", "Social Science", 0xFFA995C9,
            listOf(
                "The Rise of Nationalism in Europe", "Nationalism in India", "The Making of a Global World",
                "The Age of Industrialisation", "Print Culture and the Modern World"
            ),
            done = setOf(0, 1, 2), progress = setOf(4)
        ),
        Spec(
            "Geography", "Social Science", 0xFF7FC8C0,
            listOf(
                "Resources and Development", "Forest and Wildlife Resources", "Water Resources", "Agriculture",
                "Minerals and Energy Resources", "Manufacturing Industries", "Lifelines of National Economy"
            ),
            done = setOf(0, 1, 2, 3, 4)
        ),
        Spec(
            "Political Science", "Social Science", 0xFFE8A0BF,
            listOf("Power Sharing", "Federalism", "Gender, Religion and Caste", "Political Parties", "Outcomes of Democracy"),
            done = (0..4).toSet()
        ),
        Spec(
            "Economics", "Social Science", 0xFFE9C46A,
            listOf("Development", "Sectors of the Indian Economy", "Money and Credit", "Globalisation and the Indian Economy", "Consumer Rights"),
            done = setOf(0, 1, 2, 3)
        ),
        Spec(
            "English", null, 0xFFF5EDE3,
            listOf(
                "First Flight: A Letter to God", "First Flight: Nelson Mandela – Long Walk to Freedom",
                "First Flight: Two Stories about Flying", "First Flight: From the Diary of Anne Frank",
                "First Flight: Glimpses of India", "First Flight: Mijbil the Otter", "First Flight: Madam Rides the Bus",
                "First Flight: The Sermon at Benares", "First Flight: The Proposal", "First Flight: Poems",
                "Footprints: A Triumph of Surgery", "Footprints: The Thief's Story", "Footprints: The Midnight Visitor",
                "Footprints: A Question of Trust", "Footprints: Footprints without Feet",
                "Footprints: The Making of a Scientist", "Footprints: The Necklace", "Footprints: Bholi",
                "Footprints: The Book That Saved the Earth", "Writing and Grammar"
            )
        ),
        Spec(
            "Hindi", null, 0xFFF29E78,
            listOf(
                "क्षितिज: पद (सूरदास)", "क्षितिज: राम-लक्ष्मण-परशुराम संवाद", "क्षितिज: सवैया और कवित्त (देव)",
                "क्षितिज: आत्मकथ्य", "क्षितिज: उत्साह और अट नहीं रही है", "क्षितिज: यह दंतुरित मुस्कान और फसल",
                "क्षितिज: छाया मत छूना", "क्षितिज: कन्यादान", "क्षितिज: संगतकार", "क्षितिज: नेताजी का चश्मा",
                "क्षितिज: बालगोबिन भगत", "क्षितिज: लखनवी अंदाज़", "क्षितिज: मानवीय करुणा की दिव्य चमक",
                "क्षितिज: एक कहानी यह भी", "क्षितिज: स्त्री शिक्षा के विरोधी कुतर्कों का खंडन",
                "क्षितिज: नौबतखाने में इबादत", "क्षितिज: संस्कृति",
                "कृतिका: माता का आँचल", "कृतिका: जॉर्ज पंचम की नाक", "कृतिका: साना-साना हाथ जोड़ि",
                "कृतिका: एहि ठैयाँ झुलनी हेरानी हो रामा", "कृतिका: मैं क्यों लिखता हूँ?",
                "व्याकरण और लेखन"
            )
        )
    )

    suspend fun insertInto(dao: BoomDao) {
        specs.forEachIndexed { index, spec ->
            val sid = dao.insertSubject(
                Subject(name = spec.name, parentGroup = spec.parentGroup, color = spec.color, sortOrder = index)
            )
            dao.insertChapters(spec.chapters.mapIndexed { i, name ->
                val status = when (i) {
                    in spec.done -> ChapterStatus.COMPLETED
                    in spec.progress -> ChapterStatus.IN_PROGRESS
                    else -> ChapterStatus.NOT_STARTED
                }
                Chapter(subjectId = sid, name = name, status = status.name, sortOrder = i)
            })
        }
        // Flexible starter timetable (every day). Edit it under Planner → Timetable.
        val template = listOf(
            Triple(6 * 60 + 30, 7 * 60 + 30, "Quick revision / formulas"),
            Triple(19 * 60, 20 * 60, "SST / revision"),
            Triple(20 * 60, 21 * 60, "Maths practice"),
            Triple(21 * 60, 21 * 60 + 30, "Recall + plan tomorrow")
        )
        dao.insertSlots((1..7).flatMap { day ->
            template.map { (s, e, label) -> TimetableSlot(dayOfWeek = day, startMin = s, endMin = e, label = label) }
        })
    }
}
