package com.boom.study

import android.app.Application
import com.boom.study.data.BoomDatabase
import com.boom.study.data.BoomRepository
import com.boom.study.data.SettingsStore
import com.boom.study.notify.Notif
import com.boom.study.notify.ReminderScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class BoomApp : Application() {
    lateinit var db: BoomDatabase
        private set
    lateinit var repo: BoomRepository
        private set
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        db = BoomDatabase.get(this)
        repo = BoomRepository(db, SettingsStore(this))
        Notif.ensureChannels(this)
        appScope.launch { repo.seedIfNeeded() }
        ReminderScheduler.sync(this, repo.settings.flow.value)
    }
}
