package com.boom.study.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Palette {
    val Plum = Color(0xFF211B2B)
    val Charcoal = Color(0xFF302B36)
    val Tangerine = Color(0xFFFF8547)
    val Cream = Color(0xFFF5EDE3)
    val Lavender = Color(0xFFA995C9)
    val Sage = Color(0xFFB9D68B)
    val Gold = Color(0xFFE9C46A)
}

val themeOptions = listOf(
    "GOLD" to "Obsidian Gold", "INDIGO" to "Royal Indigo", "EMERALD" to "Emerald Night",
    "PLUM" to "Midnight Plum", "NIGHT" to "Deep Night", "CREAM" to "Champagne Cream"
)

private val GoldScheme = darkColorScheme(
    primary = Color(0xFFE6C36A), onPrimary = Color(0xFF1A1405),
    secondary = Color(0xFF9C97B8), onSecondary = Color(0xFF14121C),
    tertiary = Color(0xFF7FD1AE), onTertiary = Color(0xFF07201A),
    background = Color(0xFF0D0D10), onBackground = Color(0xFFF4EFE6),
    surface = Color(0xFF17171C), onSurface = Color(0xFFF4EFE6),
    surfaceVariant = Color(0xFF212128), onSurfaceVariant = Color(0xFFA8A3B0),
    outline = Color(0xFF34343D), error = Color(0xFFFF7B7B)
)

private val IndigoScheme = darkColorScheme(
    primary = Color(0xFFE8A598), onPrimary = Color(0xFF2A1411),
    secondary = Color(0xFF9FA8FF), onSecondary = Color(0xFF10123A),
    tertiary = Color(0xFF8FE3C8), onTertiary = Color(0xFF06241B),
    background = Color(0xFF0F1226), onBackground = Color(0xFFF6EEF0),
    surface = Color(0xFF1A1D3A), onSurface = Color(0xFFF6EEF0),
    surfaceVariant = Color(0xFF252950), onSurfaceVariant = Color(0xFFAEB1D0),
    outline = Color(0xFF3A3F6B), error = Color(0xFFFF8A8A)
)

private val EmeraldScheme = darkColorScheme(
    primary = Color(0xFF3DDBA4), onPrimary = Color(0xFF04201A),
    secondary = Color(0xFFE9D5A6), onSecondary = Color(0xFF241B05),
    tertiary = Color(0xFFF2A65A), onTertiary = Color(0xFF2A1604),
    background = Color(0xFF07151A), onBackground = Color(0xFFEAF4EF),
    surface = Color(0xFF10262A), onSurface = Color(0xFFEAF4EF),
    surfaceVariant = Color(0xFF183339), onSurfaceVariant = Color(0xFF9DB8B3),
    outline = Color(0xFF2B4A4F), error = Color(0xFFFF8A8A)
)

private val PlumScheme = darkColorScheme(
    primary = Palette.Tangerine, onPrimary = Palette.Plum,
    secondary = Palette.Lavender, onSecondary = Palette.Plum,
    tertiary = Palette.Sage, onTertiary = Palette.Plum,
    background = Palette.Plum, onBackground = Palette.Cream,
    surface = Palette.Charcoal, onSurface = Palette.Cream,
    surfaceVariant = Color(0xFF3B3544), onSurfaceVariant = Color(0xFFBDB3C8),
    outline = Color(0xFF514858), error = Color(0xFFFF7B7B)
)

private val NightScheme = darkColorScheme(
    primary = Palette.Tangerine, onPrimary = Color(0xFF14101A),
    secondary = Palette.Lavender, onSecondary = Color(0xFF14101A),
    tertiary = Palette.Sage, onTertiary = Color(0xFF14101A),
    background = Color(0xFF0E0B13), onBackground = Palette.Cream,
    surface = Color(0xFF1B1722), onSurface = Palette.Cream,
    surfaceVariant = Color(0xFF26212F), onSurfaceVariant = Color(0xFFB3A9C0),
    outline = Color(0xFF3F3749), error = Color(0xFFFF7B7B)
)

private val CreamScheme = lightColorScheme(
    primary = Color(0xFFE2661F), onPrimary = Color.White,
    secondary = Color(0xFF7D68A8), onSecondary = Color.White,
    tertiary = Color(0xFF6F9A3C), onTertiary = Color.White,
    background = Palette.Cream, onBackground = Palette.Plum,
    surface = Color(0xFFFFFBF6), onSurface = Palette.Plum,
    surfaceVariant = Color(0xFFEDE2D4), onSurfaceVariant = Color(0xFF6B6275),
    outline = Color(0xFFD3C6B6), error = Color(0xFFC62F2F)
)

val BoomTypography = Typography().copy(
    headlineLarge = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 36.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 27.sp, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.2.sp)
)

fun isLightTheme(key: String) = key == "CREAM"

@Composable
fun BoomTheme(theme: String, content: @Composable () -> Unit) {
    val base: ColorScheme = when (theme) {
        "INDIGO" -> IndigoScheme
        "EMERALD" -> EmeraldScheme
        "PLUM" -> PlumScheme
        "NIGHT" -> NightScheme
        "CREAM" -> CreamScheme
        else -> GoldScheme
    }
    val scheme = base.copy(
        secondaryContainer = base.primary.copy(alpha = 0.18f), onSecondaryContainer = base.primary,
        surfaceContainerHigh = base.surfaceVariant, surfaceContainer = base.surface
    )
    MaterialTheme(
        colorScheme = scheme,
        typography = BoomTypography,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(22.dp)
        ),
        content = content
    )
}
