package com.boom.study.viewmodel

import android.net.Uri
import android.os.Looper
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.boom.study.BoomApp
import com.boom.study.data.*
import com.boom.study.notify.Notif
import com.boom.study.notify.ReminderScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale

class BoomViewModelFactory(private val app: BoomApp) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(TrackerViewModel::class.java) -> TrackerViewModel(app.repo)
        modelClass.isAssignableFrom(PlannerViewModel::class.java) -> PlannerViewModel(app.repo)
        modelClass.isAssignableFrom(RevisionViewModel::class.java) -> RevisionViewModel(app.repo)
        modelClass.isAssignableFrom(FocusViewModel::class.java) -> FocusViewModel(app, app.repo)
        modelClass.isAssignableFrom(OverviewViewModel::class.java) -> OverviewViewModel(app.repo)
        modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(app, app.repo)
        else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    } as T
}

private fun <T> Flow<T>.eager(scope: kotlinx.coroutines.CoroutineScope, initial: T): StateFlow<T> =
    stateIn(scope, SharingStarted.WhileSubscribed(5_000), initial)

// ---------------------------------------------------------------- Tracker
class TrackerViewModel(private val repo: BoomRepository) : ViewModel() {
    val subjects = repo.subjects.eager(viewModelScope, emptyList())
    val chapters = repo.chapters.eager(viewModelScope, emptyList())

    fun addSubject(name: String, color: Long) { viewModelScope.launch { repo.addSubject(name, color) } }
    fun renameSubject(s: Subject, name: String) { viewModelScope.launch { repo.renameSubject(s, name) } }
    fun deleteSubject(s: Subject) { viewModelScope.launch { repo.deleteSubject(s) } }
    fun addChapter(subjectId: Long, name: String) { viewModelScope.launch { repo.addChapter(subjectId, name) } }
    fun renameChapter(c: Chapter, name: String) { viewModelScope.launch { repo.renameChapter(c, name) } }
    fun deleteChapter(c: Chapter) { viewModelScope.launch { repo.deleteChapter(c) } }
    fun setStatus(c: Chapter, s: ChapterStatus) { viewModelScope.launch { repo.setChapterStatus(c, s) } }
}

// ---------------------------------------------------------------- Planner
class PlannerViewModel(private val repo: BoomRepository) : ViewModel() {
    val tasks = repo.tasks.eager(viewModelScope, emptyList())
    val subjects = repo.subjects.eager(viewModelScope, emptyList())
    val chapters = repo.chapters.eager(viewModelScope, emptyList())
    val timetable = repo.timetable.eager(viewModelScope, emptyList())

    private val _day = MutableStateFlow(LocalDate.now().toEpochDay())
    val selectedDay: StateFlow<Long> = _day.asStateFlow()
    fun setDay(d: Long) { _day.value = d }
    fun shiftDay(delta: Long) { _day.value = _day.value + delta }

    fun saveTask(t: StudyTask) { viewModelScope.launch { repo.saveTask(t) } }
    fun toggleDone(t: StudyTask) { viewModelScope.launch { repo.setTaskDone(t, !t.done) } }
    fun moveTask(t: StudyTask, day: Long) { viewModelScope.launch { repo.moveTask(t, day) } }
    fun moveOverdueToToday() { viewModelScope.launch { repo.moveOverdueToToday() } }
    fun deleteTask(t: StudyTask) { viewModelScope.launch { repo.deleteTask(t) } }
    fun saveSlot(s: TimetableSlot) { viewModelScope.launch { repo.saveSlot(s) } }
    fun deleteSlot(s: TimetableSlot) { viewModelScope.launch { repo.deleteSlot(s) } }
}

// ---------------------------------------------------------------- Revision
class RevisionViewModel(private val repo: BoomRepository) : ViewModel() {
    val revisions = repo.revisions.eager(viewModelScope, emptyList())
    val subjects = repo.subjects.eager(viewModelScope, emptyList())
    val chapters = repo.chapters.eager(viewModelScope, emptyList())

    fun add(r: RevisionItem) { viewModelScope.launch { repo.addRevision(r) } }
    fun toggle(r: RevisionItem) { viewModelScope.launch { repo.setRevisionDone(r, !r.done) } }
    fun delete(r: RevisionItem) { viewModelScope.launch { repo.deleteRevision(r) } }
    fun autoPlan() {
        viewModelScope.launch {
            val n = repo.autoPlanRevisions()
            repo.notify(if (n == 0) "Every completed chapter already has revisions scheduled." else "Scheduled revisions for $n chapters.")
        }
    }
}

// ---------------------------------------------------------------- Focus timer
data class TimerUi(
    val plannedSec: Int = 25 * 60,
    val remainingSec: Int = 25 * 60,
    val running: Boolean = false,
    val started: Boolean = false,
    val isBreak: Boolean = false,
    val finished: Boolean = false,
    val subjectId: Long? = null
)

class FocusViewModel(private val app: BoomApp, private val repo: BoomRepository) : ViewModel() {
    val sessions = repo.sessions.eager(viewModelScope, emptyList())
    val subjects = repo.subjects.eager(viewModelScope, emptyList())

    private val prefs = app.getSharedPreferences("boom_timer", android.content.Context.MODE_PRIVATE)
    private val _ui = MutableStateFlow(TimerUi())
    val ui: StateFlow<TimerUi> = _ui.asStateFlow()

    private var ticker: Job? = null
    private var endAt = 0L          // wall-clock millis when the running timer ends
    private var startedAt = 0L      // wall-clock millis when the focus session started
    private var lastFocusSec = 25 * 60

    init { restore() }

    private fun restore() {
        val end = prefs.getLong("endAt", 0L)
        if (end == 0L) return
        val planned = prefs.getInt("planned", 25 * 60)
        val brk = prefs.getBoolean("break", false)
        val sid = prefs.getLong("subject", -1L).takeIf { it >= 0 }
        startedAt = prefs.getLong("startedAt", System.currentTimeMillis())
        endAt = end
        if (!brk) lastFocusSec = planned
        _ui.value = TimerUi(plannedSec = planned, remainingSec = planned, isBreak = brk, subjectId = sid, started = true)
        if (end <= System.currentTimeMillis()) finish() else startTicking()
    }

    private fun persist(running: Boolean) {
        val s = _ui.value
        prefs.edit().apply {
            if (running) {
                putLong("endAt", endAt).putInt("planned", s.plannedSec).putBoolean("break", s.isBreak)
                    .putLong("startedAt", startedAt).putLong("subject", s.subjectId ?: -1L)
            } else clear()
        }.apply()
    }

    fun select(minutes: Int) {
        val s = _ui.value
        if (s.running || minutes <= 0) return
        lastFocusSec = minutes * 60
        _ui.value = s.copy(plannedSec = minutes * 60, remainingSec = minutes * 60, started = false, finished = false, isBreak = false)
    }

    fun setSubject(id: Long?) { _ui.value = _ui.value.copy(subjectId = id) }

    fun start() {
        val s = _ui.value
        if (s.running) return
        val now = System.currentTimeMillis()
        if (s.finished || s.remainingSec <= 0) {
            _ui.value = s.copy(remainingSec = s.plannedSec, finished = false)
        }
        val rem = _ui.value.remainingSec
        endAt = now + rem * 1000L
        if (!_ui.value.started) startedAt = now
        _ui.value = _ui.value.copy(running = true, started = true, finished = false)
        persist(true)
        Notif.scheduleTimerEnd(app, endAt)
        startTicking()
    }

    private fun startTicking() {
        ticker?.cancel()
        _ui.value = _ui.value.copy(running = true, started = true)
        ticker = viewModelScope.launch {
            while (isActive) {
                val rem = (((endAt - System.currentTimeMillis()) + 999) / 1000).toInt().coerceAtLeast(0)
                _ui.value = _ui.value.copy(remainingSec = rem)
                if (rem <= 0) { finish(); break }
                delay(250)
            }
        }
    }

    fun pause() {
        val s = _ui.value
        if (!s.running) return
        ticker?.cancel()
        val rem = (((endAt - System.currentTimeMillis()) + 999) / 1000).toInt().coerceAtLeast(0)
        _ui.value = s.copy(running = false, remainingSec = rem)
        Notif.cancelTimerEnd(app)
        persist(false)
    }

    fun reset() {
        val s = _ui.value
        ticker?.cancel()
        Notif.cancelTimerEnd(app)
        persist(false)
        if (s.started && !s.isBreak && !s.finished) {
            val elapsed = s.plannedSec - (if (s.running) (((endAt - System.currentTimeMillis()) + 999) / 1000).toInt().coerceAtLeast(0) else s.remainingSec)
            if (elapsed >= 60) {
                viewModelScope.launch {
                    repo.addSession(FocusSession(startedAt = startedAt, plannedSec = s.plannedSec, actualSec = elapsed, completed = false, subjectId = s.subjectId))
                }
            }
        }
        _ui.value = s.copy(plannedSec = lastFocusSec, remainingSec = lastFocusSec, running = false, started = false, finished = false, isBreak = false)
    }

    private fun finish() {
        ticker?.cancel()
        val s = _ui.value
        Notif.cancelTimerEnd(app)
        persist(false)
        if (!s.isBreak) {
            viewModelScope.launch {
                repo.addSession(FocusSession(startedAt = startedAt, plannedSec = s.plannedSec, actualSec = s.plannedSec, completed = true, subjectId = s.subjectId))
            }
            val st = repo.settings.flow.value
            if (st.breakReminder) {
                Notif.post(app, Notif.CH_FOCUS, Notif.ID_TIMER, "Focus session complete", "Take a ${st.breakMin}-minute break.")
            }
        }
        _ui.value = s.copy(running = false, remainingSec = 0, finished = true)
    }

    fun startBreak() {
        val mins = repo.settings.flow.value.breakMin
        _ui.value = _ui.value.copy(plannedSec = mins * 60, remainingSec = mins * 60, isBreak = true, finished = false, started = false, running = false)
        start()
    }

    fun dismissFinished() {
        val s = _ui.value
        _ui.value = s.copy(plannedSec = lastFocusSec, remainingSec = lastFocusSec, finished = false, isBreak = false, started = false)
    }

    fun clearHistory() { viewModelScope.launch { repo.clearSessions() } }
}

// ---------------------------------------------------------------- Overview (dashboard + analytics)
data class SubjectStat(val subject: Subject, val total: Int, val done: Int, val inProgress: Int) {
    val fraction: Float get() = if (total == 0) 0f else done.toFloat() / total
}

data class Overview(
    val today: Long,
    val daysLeft: Long,
    val examEpochDay: Long,
    val tasksToday: List<StudyTask>,
    val tasksDoneToday: Int,
    val overdueTasks: Int,
    val focusTodayMin: Int,
    val focusGoalMin: Int,
    val taskGoal: Int,
    val streak: Int,
    val bestStreak: Int,
    val totalChapters: Int,
    val doneChapters: Int,
    val statusCounts: Map<ChapterStatus, Int>,
    val subjectStats: List<SubjectStat>,
    val dayLabels: List<String>,
    val focusLast7Min: List<Int>,
    val tasksLast7: List<Int>,
    val weekFocusMin: Int,
    val weekTasks: Int,
    val revisionTotal: Int,
    val revisionDone: Int,
    val revisionDue: Int,
    val totalTasksDone: Int,
    val totalFocusMin: Int,
    val activeLast7: List<Boolean>
) {
    val remainingChapters: Int get() = totalChapters - doneChapters
    val syllabusFraction: Float get() = if (totalChapters == 0) 0f else doneChapters.toFloat() / totalChapters
    val revisionFraction: Float get() = if (revisionTotal == 0) 0f else revisionDone.toFloat() / revisionTotal
}

private fun epochDayOf(ms: Long): Long = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate().toEpochDay()

internal class Raw(
    val subjects: List<Subject>, val chapters: List<Chapter>, val tasks: List<StudyTask>,
    val sessions: List<FocusSession>, val revisions: List<RevisionItem>
)

internal fun computeOverview(raw: Raw, s: Settings): Overview {
    val today = LocalDate.now().toEpochDay()
    val tasksToday = raw.tasks.filter { it.date == today }
        .sortedWith(compareBy<StudyTask> { it.done }.thenBy { it.startMin ?: Int.MAX_VALUE }.thenBy { it.id })

    val focusSecByDay = HashMap<Long, Int>()
    raw.sessions.forEach { val d = epochDayOf(it.startedAt); focusSecByDay[d] = (focusSecByDay[d] ?: 0) + it.actualSec }
    val doneByDay = HashMap<Long, Int>()
    raw.tasks.mapNotNull { it.completedAt }.forEach { val d = epochDayOf(it); doneByDay[d] = (doneByDay[d] ?: 0) + 1 }

    val active = HashSet<Long>()
    focusSecByDay.forEach { (d, sec) -> if (sec >= 60) active.add(d) }
    active.addAll(doneByDay.keys)
    var streak = 0
    var d = if (today in active) today else today - 1
    while (d in active) { streak++; d-- }
    var best = 0
    var run = 0
    var prev = Long.MIN_VALUE
    active.sorted().forEach { day ->
        run = if (day == prev + 1) run + 1 else 1
        if (run > best) best = run
        prev = day
    }

    val days = (6 downTo 0).map { today - it }
    val focus7 = days.map { (focusSecByDay[it] ?: 0) / 60 }
    val tasks7 = days.map { doneByDay[it] ?: 0 }

    val subjectStats = raw.subjects.map { sub ->
        val cs = raw.chapters.filter { it.subjectId == sub.id }
        SubjectStat(sub, cs.size, cs.count { ChapterStatus.from(it.status).isDone }, cs.count { it.status == ChapterStatus.IN_PROGRESS.name })
    }
    val validIds = raw.subjects.map { it.id }.toSet()
    val allCh = raw.chapters.filter { it.subjectId in validIds }

    return Overview(
        today = today,
        daysLeft = s.examEpochDay - today,
        examEpochDay = s.examEpochDay,
        tasksToday = tasksToday,
        tasksDoneToday = tasksToday.count { it.done },
        overdueTasks = raw.tasks.count { !it.done && it.date < today },
        focusTodayMin = (focusSecByDay[today] ?: 0) / 60,
        focusGoalMin = s.dailyFocusGoalMin,
        taskGoal = s.dailyTaskGoal,
        streak = streak,
        bestStreak = best,
        totalChapters = allCh.size,
        doneChapters = allCh.count { ChapterStatus.from(it.status).isDone },
        statusCounts = ChapterStatus.entries.associateWith { st -> allCh.count { it.status == st.name } },
        subjectStats = subjectStats,
        dayLabels = days.map { LocalDate.ofEpochDay(it).dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()).take(3) },
        focusLast7Min = focus7,
        tasksLast7 = tasks7,
        weekFocusMin = focus7.sum(),
        weekTasks = tasks7.sum(),
        revisionTotal = raw.revisions.size,
        revisionDone = raw.revisions.count { it.done },
        revisionDue = raw.revisions.count { !it.done && it.dueDate <= today },
        totalTasksDone = raw.tasks.count { it.done },
        totalFocusMin = focusSecByDay.values.sum() / 60,
        activeLast7 = days.map { it in active }
    )
}

class OverviewViewModel(private val repo: BoomRepository) : ViewModel() {
    private val minuteTick = flow { while (true) { emit(Unit); delay(60_000) } }

    val state: StateFlow<Overview?> = combine(
        combine(repo.subjects, repo.chapters, repo.tasks, repo.sessions, repo.revisions) { a, b, c, d, e -> Raw(a, b, c, d, e) },
        repo.settings.flow,
        minuteTick
    ) { raw, settings, _ ->
        val o: Overview? = computeOverview(raw, settings)
        o
    }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
}

// ---------------------------------------------------------------- Settings & backup
class SettingsViewModel(private val app: BoomApp, private val repo: BoomRepository) : ViewModel() {
    val settings: StateFlow<Settings> = repo.settings.flow

    fun update(change: (Settings) -> Settings) {
        repo.settings.update(change)
        ReminderScheduler.sync(app, repo.settings.flow.value)
    }

    fun exportTo(uri: Uri) {
        viewModelScope.launch {
            val json = repo.exportJson() ?: return@launch
            try {
                withContext(Dispatchers.IO) {
                    app.contentResolver.openOutputStream(uri, "wt")?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                        ?: throw IllegalStateException("Could not open the selected file")
                }
                repo.notify("Backup saved.")
            } catch (e: Exception) {
                repo.notify("Backup failed: ${e.message}")
            }
        }
    }

    fun importFrom(uri: Uri) {
        viewModelScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    app.contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) }
                        ?: throw IllegalStateException("Could not open the selected file")
                }
                if (repo.importJson(text)) {
                    ReminderScheduler.sync(app, repo.settings.flow.value)
                    repo.notify("Backup restored.")
                }
            } catch (e: Exception) {
                repo.notify("Restore failed: ${e.message}")
            }
        }
    }
}
