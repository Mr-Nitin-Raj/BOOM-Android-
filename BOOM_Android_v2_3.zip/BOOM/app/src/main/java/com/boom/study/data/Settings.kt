package com.boom.study.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.time.LocalDate

data class Settings(
    val theme: String = "GOLD",
    val dailyFocusGoalMin: Int = 180,
    val dailyTaskGoal: Int = 5,
    val examEpochDay: Long = LocalDate.of(2027, 2, 15).toEpochDay(),
    val notifSession: Boolean = false,
    val notifPending: Boolean = false,
    val notifRevision: Boolean = false,
    val notifDailyGoal: Boolean = false,
    val goalReminderHour: Int = 19,
    val breakReminder: Boolean = true,
    val breakMin: Int = 5
) {
    val anyReminderOn: Boolean get() = notifSession || notifPending || notifRevision || notifDailyGoal

    fun toJson(): JSONObject = JSONObject()
        .put("theme", theme).put("dailyFocusGoalMin", dailyFocusGoalMin).put("dailyTaskGoal", dailyTaskGoal)
        .put("examEpochDay", examEpochDay).put("notifSession", notifSession).put("notifPending", notifPending)
        .put("notifRevision", notifRevision).put("notifDailyGoal", notifDailyGoal)
        .put("goalReminderHour", goalReminderHour).put("breakReminder", breakReminder).put("breakMin", breakMin)

    companion object {
        fun fromJson(o: JSONObject): Settings {
            val d = Settings()
            return Settings(
                theme = o.optString("theme", d.theme),
                dailyFocusGoalMin = o.optInt("dailyFocusGoalMin", d.dailyFocusGoalMin),
                dailyTaskGoal = o.optInt("dailyTaskGoal", d.dailyTaskGoal),
                examEpochDay = o.optLong("examEpochDay", d.examEpochDay),
                notifSession = o.optBoolean("notifSession", d.notifSession),
                notifPending = o.optBoolean("notifPending", d.notifPending),
                notifRevision = o.optBoolean("notifRevision", d.notifRevision),
                notifDailyGoal = o.optBoolean("notifDailyGoal", d.notifDailyGoal),
                goalReminderHour = o.optInt("goalReminderHour", d.goalReminderHour),
                breakReminder = o.optBoolean("breakReminder", d.breakReminder),
                breakMin = o.optInt("breakMin", d.breakMin)
            )
        }
    }
}

/** Small SharedPreferences-backed store exposing settings as a StateFlow. */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("boom_settings", Context.MODE_PRIVATE)
    private val state = MutableStateFlow(read())
    val flow: StateFlow<Settings> = state.asStateFlow()

    var seeded: Boolean
        get() = prefs.getBoolean("seeded", false)
        set(v) { prefs.edit().putBoolean("seeded", v).apply() }

    fun update(change: (Settings) -> Settings) {
        val next = change(state.value)
        prefs.edit().putString("json", next.toJson().toString()).apply()
        state.value = next
    }

    private fun read(): Settings = try {
        prefs.getString("json", null)?.let { Settings.fromJson(JSONObject(it)) } ?: Settings()
    } catch (e: Exception) {
        Settings()
    }
}
