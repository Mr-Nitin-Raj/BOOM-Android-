package com.boom.study

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.navigation.compose.rememberNavController
import com.boom.study.ui.BoomRoot
import com.boom.study.ui.BoomTheme
import com.boom.study.ui.BoomViewModels
import com.boom.study.ui.isLightTheme
import com.boom.study.viewmodel.*

class MainActivity : ComponentActivity() {
    private val factory by lazy { BoomViewModelFactory(application as BoomApp) }
    private val tracker: TrackerViewModel by viewModels { factory }
    private val planner: PlannerViewModel by viewModels { factory }
    private val revision: RevisionViewModel by viewModels { factory }
    private val focus: FocusViewModel by viewModels { factory }
    private val overview: OverviewViewModel by viewModels { factory }
    private val settings: SettingsViewModel by viewModels { factory }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = (application as BoomApp).repo
        val vms = BoomViewModels(tracker, planner, revision, focus, overview, settings)

        setContent {
            val s by settings.settings.collectAsState()
            val light = isLightTheme(s.theme)
            val view = LocalView.current
            SideEffect {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = light
                controller.isAppearanceLightNavigationBars = light
            }
            LaunchedEffect(Unit) {
                repo.messages.collect { Toast.makeText(this@MainActivity, it, Toast.LENGTH_LONG).show() }
            }
            BoomTheme(s.theme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    BoomRoot(rememberNavController(), vms)
                }
            }
        }
    }
}
