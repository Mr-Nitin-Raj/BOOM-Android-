package com.boom.study.ui

import android.app.Activity
import android.view.WindowManager
import androidx.compose.animation.core.*
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.boom.study.data.FocusSession
import com.boom.study.viewmodel.FocusViewModel
import java.text.DateFormat
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date
import java.util.Locale

@Composable
fun FocusScreen(vm: FocusViewModel) {
    val ui by vm.ui.collectAsState()
    val sessions by vm.sessions.collectAsState()
    val subjects by vm.subjects.collectAsState()
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    LaunchedEffect(ui.finished) { if (ui.finished) haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
    var custom by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    // Keep the screen awake while a timer is running.
    DisposableEffect(ui.running) {
        val window = (ctx as? Activity)?.window
        if (ui.running) window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    val zone = ZoneId.systemDefault()
    val todayStart = LocalDate.now().atStartOfDay(zone).toInstant().toEpochMilli()
    val todaySessions = sessions.filter { it.startedAt >= todayStart }
    val todayMin = todaySessions.sumOf { it.actualSec } / 60
    val accent = if (ui.isBreak) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary
    val presets = listOf(15, 25, 45, 60)

    Box(Modifier.fillMaxSize()) {
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item { ScreenTitle("Focus", if (ui.isBreak) "Break time. Breathe." else "One thing at a time.") }
        item {
            Spacer(Modifier.height(6.dp))
            val infinite = rememberInfiniteTransition(label = "pulse")
            val pulseRaw by infinite.animateFloat(1f, 1.025f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "p")
            val pulse = if (ui.running) pulseRaw else 1f
            val frac = if (ui.plannedSec == 0) 0f else 1f - ui.remainingSec.toFloat() / ui.plannedSec
            Ring(frac, 260.dp, 14.dp, accent, Modifier.graphicsLayer { scaleX = pulse; scaleY = pulse }) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(String.format(Locale.US, "%02d:%02d", ui.remainingSec / 60, ui.remainingSec % 60), fontSize = 54.sp, fontWeight = FontWeight.Black)
                    Text(
                        when {
                            ui.isBreak -> "BREAK"
                            ui.running -> "FOCUSING"
                            ui.started -> "PAUSED"
                            else -> "${ui.plannedSec / 60} MIN SESSION"
                        },
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { m ->
                    FilterChip(
                        selected = ui.plannedSec == m * 60 && !ui.isBreak, enabled = !ui.running,
                        onClick = { vm.select(m) }, label = { Text(if (m == 25) "25 Pomodoro" else "$m min") }
                    )
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                AssistChip(onClick = { if (!ui.running) custom = true }, label = { Text("Custom timer") }, leadingIcon = { Icon(Icons.Default.Timer, null, Modifier.size(18.dp)) })
                if (!ui.isBreak) {
                    var menu by remember { mutableStateOf(false) }
                    Box {
                        AssistChip(onClick = { if (!ui.running) menu = true }, label = { Text(subjects.firstOrNull { it.id == ui.subjectId }?.name ?: "Any subject") })
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Any subject") }, onClick = { vm.setSubject(null); menu = false })
                            subjects.forEach { s -> DropdownMenuItem(text = { Text(s.name) }, onClick = { vm.setSubject(s.id); menu = false }) }
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                if (ui.running) {
                    Button(onClick = { vm.pause() }, shape = RoundedCornerShape(18.dp), contentPadding = PaddingValues(horizontal = 28.dp, vertical = 14.dp)) {
                        Icon(Icons.Default.Pause, null); Spacer(Modifier.width(8.dp)); Text("Pause")
                    }
                } else {
                    Button(onClick = { vm.start() }, shape = RoundedCornerShape(18.dp), contentPadding = PaddingValues(horizontal = 28.dp, vertical = 14.dp)) {
                        Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text(if (ui.started) "Resume" else "Start")
                    }
                }
                OutlinedButton(onClick = { vm.reset() }, shape = RoundedCornerShape(18.dp), contentPadding = PaddingValues(horizontal = 22.dp, vertical = 14.dp)) {
                    Icon(Icons.Default.Replay, null); Spacer(Modifier.width(8.dp)); Text("Reset")
                }
            }
        }
        item {
            BoomCard {
                Row {
                    Column(Modifier.weight(1f)) { SectionLabel("Focused today"); Text(fmtDuration(todayMin), style = MaterialTheme.typography.headlineMedium) }
                    Column(Modifier.weight(1f)) { SectionLabel("Sessions today"); Text("${todaySessions.count { it.completed }}", style = MaterialTheme.typography.headlineMedium) }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                SectionLabel("History", Modifier.weight(1f))
                if (sessions.isNotEmpty()) TextButton(onClick = { confirmClear = true }) { Text("Clear") }
            }
        }
        if (sessions.isEmpty()) item { EmptyState("Your finished sessions will show up here.") }
        items(sessions.take(30), key = { it.id }) { s -> SessionRow(s, subjects.firstOrNull { it.id == s.subjectId }?.name) }
    }
    Confetti(ui.finished && !ui.isBreak)
    }

    if (ui.finished) {
        AlertDialog(
            onDismissRequest = { vm.dismissFinished() },
            title = { Text(if (ui.isBreak) "Break over" else "Session complete") },
            text = { Text(if (ui.isBreak) "Ready for the next focus session?" else "Nice work. A short break helps you remember more.") },
            confirmButton = {
                if (ui.isBreak) TextButton(onClick = { vm.dismissFinished() }) { Text("OK") }
                else TextButton(onClick = { vm.startBreak() }) { Text("Start break") }
            },
            dismissButton = { if (!ui.isBreak) TextButton(onClick = { vm.dismissFinished() }) { Text("Skip break") } }
        )
    }
    if (custom) {
        var text by remember { mutableStateOf("30") }
        AlertDialog(
            onDismissRequest = { custom = false },
            title = { Text("Custom timer") },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it.filter { c -> c.isDigit() }.take(3) },
                    label = { Text("Minutes (1–180)") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                val m = text.toIntOrNull()
                TextButton(enabled = m != null && m in 1..180, onClick = { vm.select(m!!); custom = false }) { Text("Set") }
            },
            dismissButton = { TextButton(onClick = { custom = false }) { Text("Cancel") } }
        )
    }
    if (confirmClear) ConfirmDialog("Clear history?", "All recorded focus sessions will be deleted. Study streaks may change.", "Clear", { vm.clearHistory() }, { confirmClear = false })
}

@Composable
private fun SessionRow(s: FocusSession, subjectName: String?) {
    val whenText = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(s.startedAt))
    BoomCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (s.completed) Icons.Default.CheckCircle else Icons.Default.Pause, null,
                tint = if (s.completed) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("${fmtDuration(s.actualSec / 60)} ${if (s.completed) "completed" else "(ended early)"}", fontWeight = FontWeight.SemiBold)
                Text(listOfNotNull(subjectName, whenText).joinToString(" · "), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
