package com.boom.study.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.boom.study.data.ChapterStatus
import com.boom.study.viewmodel.Overview

@Composable
fun StatsScreen(o: Overview?) {
    if (o == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = MaterialTheme.colorScheme.primary) }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenTitle("Analytics", "Your preparation at a glance") }
        item { LevelCard(o) }
        item { BadgesCard(o) }
        item {
            BoomCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Ring(o.syllabusFraction, 110.dp, 12.dp, MaterialTheme.colorScheme.primary) {
                        Text("${(o.syllabusFraction * 100).toInt()}%", fontSize = 24.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(18.dp))
                    Column {
                        SectionLabel("Syllabus completion")
                        Text("${o.doneChapters} of ${o.totalChapters}", style = MaterialTheme.typography.headlineMedium)
                        Text("${o.remainingChapters} chapters remaining", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (o.daysLeft > 0 && o.remainingChapters > 0) {
                            val perWeek = o.remainingChapters.toFloat() / (o.daysLeft / 7f).coerceAtLeast(1f)
                            Text(String.format(java.util.Locale.US, "≈ %.1f chapters/week to finish", perWeek), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MiniStat("Streak", "${o.streak}d", "best ${o.bestStreak}d", Modifier.weight(1f), MaterialTheme.colorScheme.primary)
                MiniStat("Focus this week", fmtDuration(o.weekFocusMin), "last 7 days", Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MiniStat("Tasks this week", "${o.weekTasks}", "completed", Modifier.weight(1f), MaterialTheme.colorScheme.tertiary)
                MiniStat("Revision", "${(o.revisionFraction * 100).toInt()}%", "${o.revisionDone}/${o.revisionTotal} done · ${o.revisionDue} due", Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
            }
        }
        item {
            BoomCard {
                SectionLabel("Daily focus time (minutes)")
                Spacer(Modifier.height(10.dp))
                BarChart(o.focusLast7Min, o.dayLabels, MaterialTheme.colorScheme.secondary)
            }
        }
        item {
            BoomCard {
                SectionLabel("Weekly productivity (tasks completed)")
                Spacer(Modifier.height(10.dp))
                BarChart(o.tasksLast7, o.dayLabels, MaterialTheme.colorScheme.primary)
            }
        }
        item {
            BoomCard {
                SectionLabel("Chapter status")
                Spacer(Modifier.height(10.dp))
                ChapterStatus.entries.forEach { st ->
                    val n = o.statusCounts[st] ?: 0
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                        ColorDot(statusColor(st))
                        Spacer(Modifier.width(10.dp))
                        Text(st.label, Modifier.weight(1f))
                        Text("$n", fontWeight = FontWeight.Bold)
                    }
                    BoomProgress(if (o.totalChapters == 0) 0f else n.toFloat() / o.totalChapters, color = statusColor(st), height = 5.dp)
                }
            }
        }
        item { SectionLabel("Subject-wise completion", Modifier.padding(top = 4.dp)) }
        items(o.subjectStats, key = { it.subject.id }) { s ->
            BoomCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ColorDot(Color(s.subject.color), 12.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(s.subject.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Text("${(s.fraction * 100).toInt()}%", fontWeight = FontWeight.Bold, color = Color(s.subject.color))
                }
                Spacer(Modifier.height(8.dp))
                BoomProgress(s.fraction, color = Color(s.subject.color))
                Spacer(Modifier.height(4.dp))
                Text(
                    "${s.done}/${s.total} done · ${s.inProgress} in progress · ${s.total - s.done} remaining",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, caption: String, modifier: Modifier, color: Color) {
    BoomCard(modifier) {
        SectionLabel(label)
        Text(value, fontSize = 28.sp, fontWeight = FontWeight.Black, color = color)
        Text(caption, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
