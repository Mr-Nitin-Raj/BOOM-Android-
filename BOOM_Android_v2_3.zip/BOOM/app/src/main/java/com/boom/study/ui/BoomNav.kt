package com.boom.study.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import com.boom.study.viewmodel.*

private class NavTab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    NavTab("home", "Home", Icons.Default.Home),
    NavTab("syllabus", "Syllabus", Icons.Default.MenuBook),
    NavTab("planner", "Planner", Icons.Default.DateRange),
    NavTab("focus", "Focus", Icons.Default.Timer),
    NavTab("stats", "Stats", Icons.Default.BarChart)
)

private fun tabFor(route: String?): String? = when {
    route == null -> null
    route.startsWith("home") -> "home"
    route.startsWith("syllabus") || route.startsWith("subject") -> "syllabus"
    route.startsWith("planner") || route.startsWith("timetable") -> "planner"
    route.startsWith("focus") -> "focus"
    route.startsWith("stats") -> "stats"
    else -> null
}

class BoomViewModels(
    val tracker: TrackerViewModel, val planner: PlannerViewModel, val revision: RevisionViewModel,
    val focus: FocusViewModel, val overview: OverviewViewModel, val settings: SettingsViewModel
)

@Composable
fun BoomRoot(nav: NavHostController, vms: BoomViewModels) {
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val selected = tabFor(route)

    fun goTab(r: String) {
        nav.navigate(r) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            val sc = MaterialTheme.colorScheme
            Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 10.dp)) {
                Surface(
                    shape = RoundedCornerShape(30.dp), color = sc.surface, shadowElevation = 14.dp,
                    border = BorderStroke(0.5.dp, sc.outline.copy(alpha = 0.7f)), modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        tabs.forEach { t ->
                            val sel = selected == t.route
                            Row(
                                Modifier.clip(RoundedCornerShape(24.dp))
                                    .background(if (sel) sc.primary else Color.Transparent)
                                    .clickable { goTab(t.route) }
                                    .padding(horizontal = if (sel) 14.dp else 10.dp, vertical = 10.dp)
                                    .semantics { contentDescription = t.label },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(t.icon, null, tint = if (sel) sc.onPrimary else sc.onSurfaceVariant)
                                AnimatedVisibility(sel) {
                                    Text(t.label, color = sc.onPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(start = 6.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { pad ->
        val subjects by vms.tracker.subjects.collectAsState()
        val overview by vms.overview.state.collectAsState()
        NavHost(
            navController = nav, startDestination = "home", modifier = Modifier.padding(pad),
            enterTransition = { fadeIn(tween(220)) }, exitTransition = { fadeOut(tween(160)) },
            popEnterTransition = { fadeIn(tween(220)) }, popExitTransition = { fadeOut(tween(160)) }
        ) {
            composable("home") {
                HomeScreen(
                    overview = overview,
                    subjectName = { id -> subjects.firstOrNull { it.id == id }?.name ?: "" },
                    onToggleTask = { vms.planner.toggleDone(it) },
                    onNavigate = { r -> if (r in tabs.map { it.route }) goTab(r) else nav.navigate(r) { launchSingleTop = true } }
                )
            }
            composable("syllabus") { SyllabusScreen(vms.tracker) { id -> nav.navigate("subject/$id") } }
            composable("subject/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                SubjectScreen(e.arguments?.getLong("id") ?: -1L, vms.tracker) { nav.popBackStack() }
            }
            composable(
                "planner?add={add}",
                arguments = listOf(navArgument("add") { type = NavType.BoolType; defaultValue = false })
            ) { e ->
                PlannerScreen(vms.planner, e.arguments?.getBoolean("add") ?: false) { nav.navigate("timetable") { launchSingleTop = true } }
            }
            composable("timetable") { TimetableScreen(vms.planner) { nav.popBackStack() } }
            composable("focus") { FocusScreen(vms.focus) }
            composable("stats") { StatsScreen(overview) }
            composable("revision") { RevisionScreen(vms.revision) { nav.popBackStack() } }
            composable("settings") { SettingsScreen(vms.settings, { nav.popBackStack() }, { nav.navigate("timetable") { launchSingleTop = true } }) }
        }
    }
}
