package com.boom.study.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.Canvas
import androidx.compose.animation.core.Animatable
import kotlin.random.Random
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.boom.study.data.ChapterStatus
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

// ------------------------------------------------------------------ formatting helpers
fun fmtTime(min: Int): String {
    val h = min / 60
    val m = min % 60
    val h12 = if (h % 12 == 0) 12 else h % 12
    return String.format(Locale.US, "%d:%02d %s", h12, m, if (h < 12) "AM" else "PM")
}

fun fmtDate(epochDay: Long): String = LocalDate.ofEpochDay(epochDay).format(DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault()))

fun fmtDateLong(epochDay: Long): String = LocalDate.ofEpochDay(epochDay).format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.getDefault()))

fun fmtDuration(totalMin: Int): String = if (totalMin < 60) "${totalMin}m" else "${totalMin / 60}h ${totalMin % 60}m"

fun pickDate(ctx: Context, epochDay: Long, onPick: (Long) -> Unit) {
    val d = LocalDate.ofEpochDay(epochDay)
    DatePickerDialog(ctx, { _, y, m, day -> onPick(LocalDate.of(y, m + 1, day).toEpochDay()) }, d.year, d.monthValue - 1, d.dayOfMonth).show()
}

fun pickTime(ctx: Context, minutes: Int, onPick: (Int) -> Unit) {
    TimePickerDialog(ctx, { _, h, m -> onPick(h * 60 + m) }, minutes / 60, minutes % 60, false).show()
}

@Composable
fun statusColor(s: ChapterStatus): Color = when (s) {
    ChapterStatus.NOT_STARTED -> MaterialTheme.colorScheme.onSurfaceVariant
    ChapterStatus.IN_PROGRESS -> MaterialTheme.colorScheme.primary
    ChapterStatus.COMPLETED -> MaterialTheme.colorScheme.tertiary
    ChapterStatus.REVISION_PENDING -> MaterialTheme.colorScheme.secondary
    ChapterStatus.PYQ_COMPLETED -> Palette.Gold
}

// ------------------------------------------------------------------ layout pieces
@Composable
fun BoomCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    container: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.98f else 1f, tween(120), label = "press")
    Surface(
        modifier = modifier.fillMaxWidth().graphicsLayer { scaleX = scale; scaleY = scale },
        shape = RoundedCornerShape(24.dp), color = container, shadowElevation = 4.dp,
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(
            Modifier.then(
                if (onClick != null) Modifier.clickable(interactionSource = interaction, indication = LocalIndication.current, onClick = onClick) else Modifier
            ).padding(18.dp),
            content = content
        )
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onBackground)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        trailing()
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text.uppercase(), modifier = modifier, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun Reveal(index: Int, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(index * 55L); shown = true }
    AnimatedVisibility(shown, enter = fadeIn(tween(350)) + slideInVertically(tween(350)) { it / 8 }) { content() }
}

@Composable
fun EmptyState(text: String) {
    Box(Modifier.fillMaxWidth().padding(vertical = 28.dp), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun BoomProgress(fraction: Float, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary, height: Dp = 8.dp) {
    val p by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(650), label = "progress")
    LinearProgressIndicator(
        progress = { p }, modifier = modifier.fillMaxWidth().height(height),
        color = color, trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
        strokeCap = StrokeCap.Round, gapSize = 0.dp, drawStopIndicator = {}
    )
}

@Composable
fun Ring(
    progress: Float, diameter: Dp, stroke: Dp, color: Color,
    modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit = {}
) {
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(700), label = "ring")
    val track = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
    Box(modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = stroke.toPx()
            val arc = Size(this.size.width - w, this.size.height - w)
            val tl = Offset(w / 2, w / 2)
            drawArc(track, 0f, 360f, false, topLeft = tl, size = arc, style = Stroke(w, cap = StrokeCap.Round))
            if (p > 0f) drawArc(color, -90f, 360f * p, false, topLeft = tl, size = arc, style = Stroke(w, cap = StrokeCap.Round))
        }
        content()
    }
}

@Composable
fun BarChart(values: List<Int>, labels: List<String>, color: Color, modifier: Modifier = Modifier, barHeight: Dp = 110.dp) {
    val max = (values.maxOrNull() ?: 0).coerceAtLeast(1)
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
        values.forEachIndexed { i, v ->
            val frac by animateFloatAsState(v.toFloat() / max, tween(600), label = "bar$i")
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (v > 0) v.toString() else "", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(2.dp))
                Box(
                    Modifier.fillMaxWidth().height(barHeight * frac.coerceAtLeast(0.03f))
                        .background(if (v > 0) color else color.copy(alpha = 0.25f), RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                )
                Spacer(Modifier.height(4.dp))
                Text(labels.getOrElse(i) { "" }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun StatusChip(status: ChapterStatus, modifier: Modifier = Modifier) {
    val c = statusColor(status)
    Surface(modifier = modifier, shape = RoundedCornerShape(50), color = c.copy(alpha = 0.18f)) {
        Text(
            status.label, color = c, fontWeight = FontWeight.SemiBold, maxLines = 1,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun ColorDot(color: Color, size: Dp = 10.dp) {
    Box(Modifier.size(size).background(color, CircleShape))
}

// ------------------------------------------------------------------ dialogs & inputs
@Composable
fun <T> DropdownField(label: String, selectedText: String, options: List<Pair<String, T>>, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Text("$label: $selectedText", maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Text("▾")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (text, value) ->
                DropdownMenuItem(text = { Text(text, maxLines = 1, overflow = TextOverflow.Ellipsis) }, onClick = { onSelect(value); open = false })
            }
        }
    }
}

@Composable
fun TextInputDialog(
    title: String, label: String, initial: String, confirmLabel: String = "Save",
    onConfirm: (String) -> Unit, onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onConfirm(text.trim()); onDismiss() }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ConfirmDialog(title: String, message: String, confirmLabel: String = "Delete", onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { Text(confirmLabel, color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** Short celebration burst. Plays whenever [active] turns true. */
@Composable
fun Confetti(active: Boolean, modifier: Modifier = Modifier) {
    val t = remember { Animatable(0f) }
    val sc = MaterialTheme.colorScheme
    val colors = listOf(sc.primary, sc.secondary, sc.tertiary, sc.onBackground, Palette.Gold)
    val seeds = remember { List(48) { floatArrayOf(Random.nextFloat(), Random.nextFloat(), Random.nextFloat() * 2f - 1f, Random.nextFloat() * 4f + 3f) } }
    LaunchedEffect(active) {
        if (active) { t.snapTo(0f); t.animateTo(1f, tween(2200)) } else t.snapTo(0f)
    }
    if (t.value > 0f && t.value < 1f) {
        Canvas(modifier.fillMaxSize()) {
            seeds.forEachIndexed { i, s ->
                val x = size.width * s[0] + s[2] * 60f * t.value
                val y = -20f + (size.height * 0.85f) * t.value * (0.5f + s[1] * 0.5f) + 140f * t.value * t.value
                drawCircle(colors[i % colors.size].copy(alpha = 1f - t.value), radius = s[3] * 1.4f, center = Offset(x, y))
            }
        }
    }
}
