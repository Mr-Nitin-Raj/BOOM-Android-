package com.boom.study.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class ChapterStatus(val label: String) {
    NOT_STARTED("Not Started"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed"),
    REVISION_PENDING("Revision Pending"),
    PYQ_COMPLETED("PYQ Completed");

    /** A chapter counts towards syllabus progress once it has been completed. */
    val isDone: Boolean get() = this == COMPLETED || this == REVISION_PENDING || this == PYQ_COMPLETED

    companion object {
        fun from(name: String): ChapterStatus = entries.firstOrNull { it.name == name } ?: NOT_STARTED
    }
}

enum class RevisionType(val label: String) {
    FIRST("First revision"),
    SECOND("Second revision"),
    FINAL("Final revision"),
    IMPORTANT_Q("Important questions"),
    PYQ("Previous-year questions"),
    SAMPLE_PAPER("Sample paper practice");

    companion object {
        fun from(name: String): RevisionType = entries.firstOrNull { it.name == name } ?: FIRST
    }
}

@Entity(tableName = "subjects")
data class Subject(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val parentGroup: String? = null,
    val color: Long,
    val sortOrder: Int = 0,
    val custom: Boolean = false
)

@Entity(
    tableName = "chapters",
    foreignKeys = [ForeignKey(
        entity = Subject::class, parentColumns = ["id"], childColumns = ["subjectId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("subjectId")]
)
data class Chapter(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val name: String,
    val status: String = ChapterStatus.NOT_STARTED.name,
    val sortOrder: Int = 0
)

@Entity(
    tableName = "tasks",
    foreignKeys = [
        ForeignKey(entity = Subject::class, parentColumns = ["id"], childColumns = ["subjectId"], onDelete = ForeignKey.SET_NULL),
        ForeignKey(entity = Chapter::class, parentColumns = ["id"], childColumns = ["chapterId"], onDelete = ForeignKey.SET_NULL)
    ],
    indices = [Index("subjectId"), Index("chapterId"), Index("date")]
)
data class StudyTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subjectId: Long? = null,
    val chapterId: Long? = null,
    /** Local date as epoch day. */
    val date: Long,
    /** Minutes after midnight, null when no time slot is set. */
    val startMin: Int? = null,
    val endMin: Int? = null,
    /** 0 = low, 1 = medium, 2 = high */
    val priority: Int = 1,
    val done: Boolean = false,
    val completedAt: Long? = null,
    val rescheduled: Int = 0
)

@Entity(
    tableName = "revisions",
    foreignKeys = [
        ForeignKey(entity = Subject::class, parentColumns = ["id"], childColumns = ["subjectId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Chapter::class, parentColumns = ["id"], childColumns = ["chapterId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("subjectId"), Index("chapterId"), Index("dueDate")]
)
data class RevisionItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val chapterId: Long? = null,
    val type: String,
    val dueDate: Long,
    val done: Boolean = false,
    val doneAt: Long? = null
)

@Entity(tableName = "sessions")
data class FocusSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startedAt: Long,
    val plannedSec: Int,
    val actualSec: Int,
    val completed: Boolean,
    val subjectId: Long? = null
)

@Entity(tableName = "timetable")
data class TimetableSlot(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** ISO day of week: 1 = Monday ... 7 = Sunday */
    val dayOfWeek: Int,
    val startMin: Int,
    val endMin: Int,
    val label: String,
    val subjectId: Long? = null
)
