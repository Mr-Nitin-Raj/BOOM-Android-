package com.boom.study.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.boom.study.data.Chapter
import com.boom.study.data.StudyTask
import com.boom.study.data.Subject
import com.boom.study.data.TimetableSlot
import com.boom.study.viewmodel.PlannerViewModel
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun priorityColor(p: Int): Color = when (p) {
    2 -> MaterialTheme.colorScheme.primary
    1 -> MaterialTheme.colorScheme.secondary
    else -> MaterialTheme.colorScheme.tertiary
}

val priorityNames = listOf("Low", "Medium", "High")

/** One task line, shared by the Home and Planner screens. */
@Composable
fun TaskRow(task: StudyTask, subjectLabel: String, onToggle: () -> Unit, onMenu: (@Composable () -> Unit)? = null) {
    BoomCard(onClick = onToggle) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (task.done) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, null,
                tint = if (task.done) MaterialTheme.colorScheme.tertiary else priorityColor(task.priority)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    task.title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Medium),
                    textDecoration = if (task.done) TextDecoration.LineThrough else null,
                    color = if (task.done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                )
                val time = if (task.startMin != null) fmtTime(task.startMin) + (if (task.endMin != null) " – " + fmtTime(task.endMin) else "") else null
                val sub = listOfNotNull(subjectLabel.takeIf { it.isNotBlank() }, time, "${priorityNames[task.priority.coerceIn(0, 2)]} priority").joinToString(" · ")
                Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (onMenu != null) onMenu()
        }
    }
}

@Composable
fun TaskDialog(
    initial: StudyTask?, defaultDay: Long, subjects: List<Subject>, chapters: List<Chapter>,
    onSave: (StudyTask) -> Unit, onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var subjectId by remember { mutableStateOf(initial?.subjectId) }
    var chapterId by remember { mutableStateOf(initial?.chapterId) }
    var day by remember { mutableLongStateOf(initial?.date ?: defaultDay) }
    var start by remember { mutableStateOf(initial?.startMin) }
    var end by remember { mutableStateOf(initial?.endMin) }
    var priority by remember { mutableIntStateOf(initial?.priority ?: 1) }
    var error by remember { mutableStateOf<String?>(null) }

    val subjectOptions: List<Pair<String, Long?>> = listOf("None" to null) + subjects.map { it.name to it.id }
    val chapterOptions: List<Pair<String, Long?>> = listOf<Pair<String, Long?>>("None" to null) +
        chapters.filter { it.subjectId == subjectId }.map { it.name to it.id }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New task" else "Edit task") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it; error = null }, label = { Text("What will you study?") }, modifier = Modifier.fillMaxWidth())
                DropdownField("Subject", subjects.firstOrNull { it.id == subjectId }?.name ?: "None", subjectOptions, { subjectId = it; chapterId = null })
                if (subjectId != null) {
                    DropdownField("Chapter", chapters.firstOrNull { it.id == chapterId }?.name ?: "None", chapterOptions, { chapterId = it })
                }
                OutlinedButton(onClick = { pickDate(ctx, day) { day = it } }, modifier = Modifier.fillMaxWidth()) { Text("Date: ${fmtDate(day)}") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pickTime(ctx, start ?: 18 * 60) { start = it; if (end == null || end!! <= it) end = minOf(it + 60, 23 * 60 + 59) } }, modifier = Modifier.weight(1f)) {
                        Text(if (start != null) "From ${fmtTime(start!!)}" else "Start time")
                    }
                    OutlinedButton(onClick = { pickTime(ctx, end ?: ((start ?: 17 * 60) + 60)) { end = it } }, modifier = Modifier.weight(1f)) {
                        Text(if (end != null) "To ${fmtTime(end!!)}" else "End time")
                    }
                }
                if (start != null || end != null) TextButton(onClick = { start = null; end = null }) { Text("Clear time slot") }
                SectionLabel("Priority")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    priorityNames.forEachIndexed { i, n -> FilterChip(selected = priority == i, onClick = { priority = i }, label = { Text(n) }) }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val s = start
                val e = end
                when {
                    title.isBlank() -> error = "Please enter a task title."
                    s != null && e != null && e <= s -> error = "End time must be after the start time."
                    else -> {
                        onSave(
                            (initial ?: StudyTask(title = "", date = day)).copy(
                                title = title.trim(), subjectId = subjectId, chapterId = chapterId, date = day,
                                startMin = s, endMin = e, priority = priority
                            )
                        )
                        onDismiss()
                    }
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun PlannerScreen(vm: PlannerViewModel, openAddInitially: Boolean, onEditTimetable: () -> Unit) {
    val ctx = LocalContext.current
    val tasks by vm.tasks.collectAsState()
    val subjects by vm.subjects.collectAsState()
    val chapters by vm.chapters.collectAsState()
    val timetable by vm.timetable.collectAsState()
    val day by vm.selectedDay.collectAsState()
    val today = LocalDate.now().toEpochDay()

    var weekMode by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf(openAddInitially) }
    var editing by remember { mutableStateOf<StudyTask?>(null) }
    var deleting by remember { mutableStateOf<StudyTask?>(null) }
    val subjectName: (Long?) -> String = { id -> subjects.firstOrNull { it.id == id }?.name ?: "" }
    val overdue = tasks.count { !it.done && it.date < today }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            ScreenTitle("Planner", "Plan it. Do it. Tick it.") {
                IconButton(onClick = onEditTimetable) { Icon(Icons.Default.Schedule, "Edit timetable", tint = MaterialTheme.colorScheme.primary) }
            }
            TabRow(
                selectedTabIndex = if (weekMode) 1 else 0, containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                Tab(selected = !weekMode, onClick = { weekMode = false }, text = { Text("Day") })
                Tab(selected = weekMode, onClick = { weekMode = true }, text = { Text("Week") })
            }
            Spacer(Modifier.height(8.dp))
            if (!weekMode) DayView(
                vm, day, today, tasks, timetable, overdue, subjectName,
                onPickDate = { pickDate(ctx, day) { vm.setDay(it) } },
                onEdit = { editing = it }, onDelete = { deleting = it }
            ) else WeekView(
                vm, day, tasks, timetable, subjectName,
                onOpenDay = { vm.setDay(it); weekMode = false }
            )
        }
        FloatingActionButton(
            onClick = { dialog = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp),
            containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary
        ) { Icon(Icons.Default.Add, "Add task") }
    }

    if (dialog) TaskDialog(null, if (weekMode) today else day, subjects, chapters, { vm.saveTask(it) }, { dialog = false })
    editing?.let { t -> TaskDialog(t, t.date, subjects, chapters, { vm.saveTask(it) }, { editing = null }) }
    deleting?.let { t -> ConfirmDialog("Delete task?", "\"${t.title}\" will be removed.", onConfirm = { vm.deleteTask(t) }, onDismiss = { deleting = null }) }
}

@Composable
private fun DayView(
    vm: PlannerViewModel, day: Long, today: Long, tasks: List<StudyTask>, timetable: List<TimetableSlot>, overdue: Int,
    subjectName: (Long?) -> String, onPickDate: () -> Unit, onEdit: (StudyTask) -> Unit, onDelete: (StudyTask) -> Unit
) {
    val ctx = LocalContext.current
    val dayTasks = tasks.filter { it.date == day }
        .sortedWith(compareBy<StudyTask> { it.done }.thenBy { it.startMin ?: Int.MAX_VALUE }.thenBy { it.id })
    val done = dayTasks.count { it.done }
    val slots = timetable.filter { it.dayOfWeek == LocalDate.ofEpochDay(day).dayOfWeek.value }

    LazyColumn(contentPadding = PaddingValues(bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.shiftDay(-1) }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Previous day") }
                Column(Modifier.weight(1f).clickable(onClick = onPickDate), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(fmtDate(day), style = MaterialTheme.typography.titleMedium)
                    Text(if (day == today) "Today" else if (day == today + 1) "Tomorrow" else if (day == today - 1) "Yesterday" else "Tap to pick a date", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { vm.shiftDay(1) }) { Icon(Icons.Default.ChevronRight, "Next day") }
                if (day != today) TextButton(onClick = { vm.setDay(today) }) { Text("Today") }
            }
        }
        if (overdue > 0) item {
            BoomCard(container = MaterialTheme.colorScheme.surfaceVariant) {
                Text("$overdue unfinished task${if (overdue == 1) "" else "s"} from earlier days", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Button(onClick = { vm.moveOverdueToToday() }) { Text("Move all to today") }
            }
        }
        item {
            BoomCard {
                Row {
                    SectionLabel("Day progress", Modifier.weight(1f))
                    Text("$done / ${dayTasks.size} done", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(8.dp))
                BoomProgress(if (dayTasks.isEmpty()) 0f else done.toFloat() / dayTasks.size, color = MaterialTheme.colorScheme.tertiary)
            }
        }
        if (dayTasks.isEmpty()) item { EmptyState("No tasks for this day. Tap + to plan one.") }
        items(dayTasks, key = { it.id }) { t ->
            TaskRow(t, subjectName(t.subjectId), onToggle = { vm.toggleDone(t) }) {
                var menu by remember { mutableStateOf(false) }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Task options", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Edit") }, onClick = { menu = false; onEdit(t) })
                        DropdownMenuItem(text = { Text("Move to tomorrow") }, onClick = { menu = false; vm.moveTask(t, today + 1) })
                        DropdownMenuItem(text = { Text("Move to today") }, onClick = { menu = false; vm.moveTask(t, today) })
                        DropdownMenuItem(text = { Text("Pick another date") }, onClick = { menu = false; pickDate(ctx, t.date) { vm.moveTask(t, it) } })
                        DropdownMenuItem(text = { Text("Delete", color = MaterialTheme.colorScheme.error) }, onClick = { menu = false; onDelete(t) })
                    }
                }
            }
        }
        if (slots.isNotEmpty()) {
            item { SectionLabel("Timetable · ${LocalDate.ofEpochDay(day).dayOfWeek.getDisplayName(TextStyle.FULL, Locale.getDefault())}", Modifier.padding(top = 8.dp)) }
            items(slots, key = { "slot${it.id}" }) { SlotRow(it, subjectName(it.subjectId)) }
        }
    }
}

@Composable
private fun SlotRow(s: TimetableSlot, subjectLabel: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        ColorDot(MaterialTheme.colorScheme.primary, 8.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(s.label, fontWeight = FontWeight.SemiBold)
            if (subjectLabel.isNotBlank()) Text(subjectLabel, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("${fmtTime(s.startMin)} – ${fmtTime(s.endMin)}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
    }
}

@Composable
private fun WeekView(
    vm: PlannerViewModel, day: Long, tasks: List<StudyTask>, timetable: List<TimetableSlot>,
    subjectName: (Long?) -> String, onOpenDay: (Long) -> Unit
) {
    val monday = LocalDate.ofEpochDay(day).with(DayOfWeek.MONDAY).toEpochDay()
    val today = LocalDate.now().toEpochDay()
    LazyColumn(contentPadding = PaddingValues(bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.shiftDay(-7) }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Previous week") }
                Text("${fmtDate(monday)} – ${fmtDate(monday + 6)}", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = { vm.shiftDay(7) }) { Icon(Icons.Default.ChevronRight, "Next week") }
            }
        }
        items((0..6).map { monday + it }, key = { it }) { d ->
            val dt = tasks.filter { it.date == d }.sortedWith(compareBy<StudyTask> { it.done }.thenBy { it.startMin ?: Int.MAX_VALUE })
            val slots = timetable.filter { it.dayOfWeek == LocalDate.ofEpochDay(d).dayOfWeek.value }
            BoomCard(onClick = { onOpenDay(d) }, container = if (d == today) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(fmtDate(d), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, color = if (d == today) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    Text("${dt.count { it.done }}/${dt.size} done", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (dt.isEmpty()) Text("No tasks", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                dt.take(4).forEach { t ->
                    Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (t.done) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, null, Modifier.size(16.dp), tint = if (t.done) MaterialTheme.colorScheme.tertiary else priorityColor(t.priority))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            listOfNotNull(t.startMin?.let { fmtTime(it) }, t.title).joinToString("  "),
                            maxLines = 1, style = MaterialTheme.typography.bodyMedium,
                            textDecoration = if (t.done) TextDecoration.LineThrough else null
                        )
                    }
                }
                if (dt.size > 4) Text("+${dt.size - 4} more", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (slots.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text("Timetable: " + slots.joinToString(" · ") { fmtTime(it.startMin) }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary, maxLines = 2)
                }
            }
        }
    }
}

@Composable
fun TimetableScreen(vm: PlannerViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val timetable by vm.timetable.collectAsState()
    val subjects by vm.subjects.collectAsState()
    var dow by remember { mutableIntStateOf(LocalDate.now().dayOfWeek.value) }
    var editing by remember { mutableStateOf<TimetableSlot?>(null) }
    var creating by remember { mutableStateOf(false) }
    val slots = timetable.filter { it.dayOfWeek == dow }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                    Column {
                        Text("Timetable", style = MaterialTheme.typography.headlineMedium)
                        Text("Your repeating weekly routine", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    DayOfWeek.entries.forEach { d ->
                        FilterChip(
                            selected = dow == d.value, onClick = { dow = d.value }, modifier = Modifier.weight(1f),
                            label = { Text(d.getDisplayName(TextStyle.SHORT, Locale.getDefault()).take(2), maxLines = 1) }
                        )
                    }
                }
            }
            if (slots.isEmpty()) item { EmptyState("No slots for this day.") }
            items(slots, key = { it.id }) { s ->
                BoomCard(onClick = { editing = s }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.label, style = MaterialTheme.typography.titleMedium)
                            Text("${fmtTime(s.startMin)} – ${fmtTime(s.endMin)}" + (subjects.firstOrNull { it.id == s.subjectId }?.let { " · ${it.name}" } ?: ""), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { vm.deleteSlot(s) }) { Icon(Icons.Default.Delete, "Delete slot", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { creating = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp),
            containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary,
            icon = { Icon(Icons.Default.Add, null) }, text = { Text("Add slot") }
        )
    }
    if (creating) SlotDialog(null, dow, subjects, { vm.saveSlot(it) }) { creating = false }
    editing?.let { s -> SlotDialog(s, s.dayOfWeek, subjects, { vm.saveSlot(it) }) { editing = null } }
}

@Composable
private fun SlotDialog(initial: TimetableSlot?, dow: Int, subjects: List<Subject>, onSave: (TimetableSlot) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var label by remember { mutableStateOf(initial?.label ?: "") }
    var start by remember { mutableIntStateOf(initial?.startMin ?: 18 * 60) }
    var end by remember { mutableIntStateOf(initial?.endMin ?: 19 * 60) }
    var subjectId by remember { mutableStateOf(initial?.subjectId) }
    var everyDay by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val options: List<Pair<String, Long?>> = listOf("None" to null) + subjects.map { it.name to it.id }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "New slot" else "Edit slot") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(label, { label = it; error = null }, label = { Text("What happens here?") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pickTime(ctx, start) { start = it } }, modifier = Modifier.weight(1f)) { Text("From ${fmtTime(start)}") }
                    OutlinedButton(onClick = { pickTime(ctx, end) { end = it } }, modifier = Modifier.weight(1f)) { Text("To ${fmtTime(end)}") }
                }
                DropdownField("Subject", subjects.firstOrNull { it.id == subjectId }?.name ?: "None", options, { subjectId = it })
                if (initial == null) Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = everyDay, onCheckedChange = { everyDay = it })
                    Text("Repeat on every day")
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    label.isBlank() -> error = "Please enter a label."
                    end <= start -> error = "End time must be after the start time."
                    else -> {
                        if (initial == null && everyDay) {
                            (1..7).forEach { d -> onSave(TimetableSlot(dayOfWeek = d, startMin = start, endMin = end, label = label.trim(), subjectId = subjectId)) }
                        } else {
                            onSave((initial ?: TimetableSlot(dayOfWeek = dow, startMin = start, endMin = end, label = "")).copy(startMin = start, endMin = end, label = label.trim(), subjectId = subjectId))
                        }
                        onDismiss()
                    }
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
