package com.boom.study.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.boom.study.data.Chapter
import com.boom.study.data.ChapterStatus
import com.boom.study.data.Subject
import com.boom.study.viewmodel.TrackerViewModel

private val customColors = listOf(0xFFFF8547, 0xFFA995C9, 0xFFB9D68B, 0xFF7FC8C0, 0xFFE8A0BF, 0xFFE9C46A)

private data class Prog(val total: Int, val done: Int) {
    val fraction get() = if (total == 0) 0f else done.toFloat() / total
}

private fun progressOf(chapters: List<Chapter>, subjectId: Long): Prog {
    val cs = chapters.filter { it.subjectId == subjectId }
    return Prog(cs.size, cs.count { ChapterStatus.from(it.status).isDone })
}

@Composable
fun SyllabusScreen(vm: TrackerViewModel, onOpen: (Long) -> Unit) {
    val subjects by vm.subjects.collectAsState()
    val chapters by vm.chapters.collectAsState()
    var addSubject by remember { mutableStateOf(false) }

    val social = subjects.filter { it.parentGroup == "Social Science" }
    val others = subjects.filter { it.parentGroup == null }
    val socialDone = social.sumOf { progressOf(chapters, it.id).done }
    val socialTotal = social.sumOf { progressOf(chapters, it.id).total }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { ScreenTitle("Syllabus", "Tap a subject to track its chapters") }
            items(others.filter { it.name != "English" && it.name != "Hindi" && !it.custom }, key = { it.id }) { s ->
                SubjectCard(s, progressOf(chapters, s.id)) { onOpen(s.id) }
            }
            if (social.isNotEmpty()) {
                item {
                    Column {
                        Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            SectionLabel("Social Science", Modifier.weight(1f))
                            Text("$socialDone / $socialTotal done", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(6.dp))
                        BoomProgress(if (socialTotal == 0) 0f else socialDone.toFloat() / socialTotal, color = MaterialTheme.colorScheme.secondary)
                    }
                }
                items(social, key = { it.id }) { s -> SubjectCard(s, progressOf(chapters, s.id)) { onOpen(s.id) } }
            }
            items(others.filter { it.name == "English" || it.name == "Hindi" }, key = { it.id }) { s ->
                SubjectCard(s, progressOf(chapters, s.id)) { onOpen(s.id) }
            }
            val custom = others.filter { it.custom }
            if (custom.isNotEmpty()) {
                item { SectionLabel("Your subjects", Modifier.padding(top = 6.dp)) }
                items(custom, key = { it.id }) { s -> SubjectCard(s, progressOf(chapters, s.id)) { onOpen(s.id) } }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { addSubject = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp),
            containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary,
            icon = { Icon(Icons.Default.Add, null) }, text = { Text("Subject") }
        )
    }
    if (addSubject) {
        TextInputDialog("New subject", "Subject name", "", "Add", onConfirm = { name ->
            vm.addSubject(name, customColors[subjects.size % customColors.size])
        }, onDismiss = { addSubject = false })
    }
}

@Composable
private fun SubjectCard(subject: Subject, p: Prog, onClick: () -> Unit) {
    val color = Color(subject.color)
    BoomCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ColorDot(color, 12.dp)
            Spacer(Modifier.width(10.dp))
            Text(subject.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Text("${(p.fraction * 100).toInt()}%", fontWeight = FontWeight.Bold, color = color)
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(10.dp))
        BoomProgress(p.fraction, color = color)
        Spacer(Modifier.height(6.dp))
        Text("${p.done} of ${p.total} chapters completed", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun SubjectScreen(subjectId: Long, vm: TrackerViewModel, onBack: () -> Unit) {
    val subjects by vm.subjects.collectAsState()
    val allChapters by vm.chapters.collectAsState()
    val subject = subjects.firstOrNull { it.id == subjectId }
    if (subject == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Subject not found", color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = onBack) { Text("Go back") }
            }
        }
        return
    }
    val chapters = allChapters.filter { it.subjectId == subjectId }
    val p = progressOf(allChapters, subjectId)
    var filter by remember { mutableStateOf<ChapterStatus?>(null) }
    var addChapter by remember { mutableStateOf(false) }
    var editChapter by remember { mutableStateOf<Chapter?>(null) }
    var deleteChapter by remember { mutableStateOf<Chapter?>(null) }
    var renameSubject by remember { mutableStateOf(false) }
    var deleteSubject by remember { mutableStateOf(false) }
    val color = Color(subject.color)
    val shown = chapters.filter { filter == null || it.status == filter!!.name }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 4.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                    Column(Modifier.weight(1f)) {
                        Text(subject.name, style = MaterialTheme.typography.headlineMedium, maxLines = 1)
                        if (subject.parentGroup != null) Text(subject.parentGroup, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (subject.custom) {
                        IconButton(onClick = { renameSubject = true }) { Icon(Icons.Default.Edit, "Rename subject") }
                        IconButton(onClick = { deleteSubject = true }) { Icon(Icons.Default.Delete, "Delete subject") }
                    }
                }
            }
            item {
                BoomCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${(p.fraction * 100).toInt()}%", style = MaterialTheme.typography.headlineMedium, color = color)
                        Spacer(Modifier.width(12.dp))
                        Text("${p.done} of ${p.total} chapters completed", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.height(8.dp))
                    BoomProgress(p.fraction, color = color)
                }
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("All ${chapters.size}") }) }
                    items(ChapterStatus.entries.toList()) { st ->
                        val n = chapters.count { it.status == st.name }
                        FilterChip(selected = filter == st, onClick = { filter = if (filter == st) null else st }, label = { Text("${st.label} $n") })
                    }
                }
            }
            if (shown.isEmpty()) item { EmptyState(if (chapters.isEmpty()) "No chapters yet. Tap Add chapter." else "No chapters with this status.") }
            items(shown, key = { it.id }) { c ->
                ChapterRow(c, onStatus = { vm.setStatus(c, it) }, onEdit = { editChapter = c }, onDelete = { deleteChapter = c })
            }
        }
        ExtendedFloatingActionButton(
            onClick = { addChapter = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp),
            containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary,
            icon = { Icon(Icons.Default.Add, null) }, text = { Text("Add chapter") }
        )
    }

    if (addChapter) TextInputDialog("New chapter", "Chapter name", "", "Add", { vm.addChapter(subjectId, it) }, { addChapter = false })
    editChapter?.let { c -> TextInputDialog("Edit chapter", "Chapter name", c.name, "Save", { vm.renameChapter(c, it) }, { editChapter = null }) }
    deleteChapter?.let { c -> ConfirmDialog("Delete chapter?", "\"${c.name}\" and its revision items will be removed.", onConfirm = { vm.deleteChapter(c) }, onDismiss = { deleteChapter = null }) }
    if (renameSubject) TextInputDialog("Rename subject", "Subject name", subject.name, "Save", { vm.renameSubject(subject, it) }, { renameSubject = false })
    if (deleteSubject) ConfirmDialog("Delete subject?", "All chapters, revisions and links for ${subject.name} will be removed.", onConfirm = { vm.deleteSubject(subject); onBack() }, onDismiss = { deleteSubject = false })
}

@Composable
private fun ChapterRow(c: Chapter, onStatus: (ChapterStatus) -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val status = ChapterStatus.from(c.status)
    var menu by remember { mutableStateOf(false) }
    BoomCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(c.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Medium))
            IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) { Icon(Icons.Default.Edit, "Edit chapter", Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant) }
            IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) { Icon(Icons.Default.Delete, "Delete chapter", Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        Spacer(Modifier.height(8.dp))
        Box {
            StatusChip(status, Modifier.clickable { menu = true })
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                ChapterStatus.entries.forEach { st ->
                    DropdownMenuItem(
                        text = { Text(st.label, color = statusColor(st), fontWeight = if (st == status) FontWeight.Bold else FontWeight.Normal) },
                        onClick = { onStatus(st); menu = false }
                    )
                }
            }
        }
    }
}
