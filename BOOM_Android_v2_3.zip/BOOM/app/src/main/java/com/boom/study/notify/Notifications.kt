package com.boom.study.notify

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.boom.study.BoomApp
import com.boom.study.MainActivity
import com.boom.study.R
import com.boom.study.data.Settings
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.util.concurrent.TimeUnit

object Notif {
    const val CH_REMIND = "boom_reminders"
    const val CH_FOCUS = "boom_focus"
    const val ID_TIMER = 9001
    const val ID_BREAK = 9002

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_REMIND, "Study reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Upcoming sessions, pending tasks, revisions and daily goals"
        })
        nm.createNotificationChannel(NotificationChannel(CH_FOCUS, "Focus timer", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Focus session finished and break reminders"
        })
    }

    fun canPost(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun post(ctx: Context, channel: String, id: Int, title: String, text: String) {
        if (!canPost(ctx)) return
        ensureChannels(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setColor(0xFFE6C36A.toInt())
            .build()
        try {
            ctx.getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    private fun timerIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 1, Intent(ctx, TimerEndReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** Inexact alarm (no special permission) that posts a "session finished" notification. */
    fun scheduleTimerEnd(ctx: Context, atMillis: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, timerIntent(ctx))
    }

    fun cancelTimerEnd(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(timerIntent(ctx))
    }
}

class TimerEndReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val app = context.applicationContext as BoomApp
        val s = app.repo.settings.flow.value
        val text = if (s.breakReminder) "Great focus! Take a ${s.breakMin}-minute break." else "Your focus session is complete."
        Notif.post(context, Notif.CH_FOCUS, Notif.ID_TIMER, "Focus session complete", text)
    }
}

object ReminderScheduler {
    private const val WORK = "boom_reminders"

    fun sync(ctx: Context, s: Settings) {
        val wm = WorkManager.getInstance(ctx)
        if (s.anyReminderOn) {
            wm.enqueueUniquePeriodicWork(
                WORK, ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<ReminderWorker>(15, TimeUnit.MINUTES).build()
            )
        } else {
            wm.cancelUniqueWork(WORK)
        }
    }
}

/** Runs about every 15 minutes (Android decides the exact timing) and posts each reminder at most once per day. */
class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private val log = ctx.getSharedPreferences("boom_notif_log", Context.MODE_PRIVATE)

    private fun once(key: String): Boolean {
        if (log.contains(key)) return false
        log.edit().putBoolean(key, true).apply()
        return true
    }

    override suspend fun doWork(): Result {
        return try {
            val app = applicationContext as BoomApp
            val s = app.repo.settings.flow.value
            if (!s.anyReminderOn || !Notif.canPost(applicationContext)) return Result.success()
            val dao = app.db.dao()
            val today = LocalDate.now()
            val day = today.toEpochDay()
            if (log.getLong("day", -1L) != day) log.edit().clear().putLong("day", day).apply()
            val nowMin = LocalTime.now().let { it.hour * 60 + it.minute }
            val tasks = dao.tasksOn(day).filter { !it.done }

            if (s.notifSession) {
                tasks.filter { it.startMin != null && nowMin >= it.startMin - 20 && nowMin <= it.startMin + 5 }.forEach {
                    if (once("t${it.id}")) {
                        Notif.post(applicationContext, Notif.CH_REMIND, 1000 + (it.id % 5000).toInt(), "Study session soon", "${it.title} starts shortly.")
                    }
                }
            }
            if (s.notifPending && nowMin >= 20 * 60 && tasks.isNotEmpty() && once("pending")) {
                Notif.post(applicationContext, Notif.CH_REMIND, 7001, "Pending tasks",
                    "${tasks.size} task${if (tasks.size == 1) "" else "s"} still to finish today.")
            }
            if (s.notifRevision && nowMin >= 8 * 60) {
                val due = dao.dueRevisionCount(day)
                if (due > 0 && once("revision")) {
                    Notif.post(applicationContext, Notif.CH_REMIND, 7002, "Revision due", "$due revision item${if (due == 1) "" else "s"} waiting for you.")
                }
            }
            if (s.notifDailyGoal && nowMin >= s.goalReminderHour * 60) {
                val zone = ZoneId.systemDefault()
                val from = today.atStartOfDay(zone).toInstant().toEpochMilli()
                val mins = dao.focusSecondsBetween(from, from + 24L * 3600 * 1000) / 60
                if (mins < s.dailyFocusGoalMin && once("goal")) {
                    Notif.post(applicationContext, Notif.CH_REMIND, 7003, "Daily goal",
                        "$mins of ${s.dailyFocusGoalMin} focus minutes done. A short session will help!")
                }
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
