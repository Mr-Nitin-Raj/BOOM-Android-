package com.boom.study.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BoomDao {
    // Subjects
    @Query("SELECT * FROM subjects ORDER BY sortOrder, id")
    fun subjects(): Flow<List<Subject>>
    @Insert suspend fun insertSubject(s: Subject): Long
    @Insert suspend fun insertSubjects(s: List<Subject>): List<Long>
    @Update suspend fun updateSubject(s: Subject)
    @Delete suspend fun deleteSubject(s: Subject)
    @Query("SELECT COUNT(*) FROM subjects") suspend fun subjectCount(): Int

    // Chapters
    @Query("SELECT * FROM chapters ORDER BY subjectId, sortOrder, id")
    fun chapters(): Flow<List<Chapter>>
    @Insert suspend fun insertChapter(c: Chapter): Long
    @Insert suspend fun insertChapters(c: List<Chapter>)
    @Update suspend fun updateChapter(c: Chapter)
    @Delete suspend fun deleteChapter(c: Chapter)
    @Query("SELECT COALESCE(MAX(sortOrder), -1) FROM chapters WHERE subjectId = :sid")
    suspend fun maxChapterOrder(sid: Long): Int
    @Query("SELECT * FROM chapters ORDER BY subjectId, sortOrder, id")
    suspend fun chaptersOnce(): List<Chapter>

    // Tasks
    @Query("SELECT * FROM tasks ORDER BY date, startMin, id")
    fun tasks(): Flow<List<StudyTask>>
    @Insert suspend fun insertTask(t: StudyTask): Long
    @Update suspend fun updateTask(t: StudyTask)
    @Delete suspend fun deleteTask(t: StudyTask)
    @Query("SELECT * FROM tasks WHERE date = :d ORDER BY startMin, id")
    suspend fun tasksOn(d: Long): List<StudyTask>
    @Query("SELECT * FROM tasks WHERE date < :d AND done = 0")
    suspend fun overdueTasks(d: Long): List<StudyTask>

    // Revisions
    @Query("SELECT * FROM revisions ORDER BY done, dueDate, id")
    fun revisions(): Flow<List<RevisionItem>>
    @Insert suspend fun insertRevision(r: RevisionItem): Long
    @Update suspend fun updateRevision(r: RevisionItem)
    @Delete suspend fun deleteRevision(r: RevisionItem)
    @Query("SELECT COUNT(*) FROM revisions WHERE chapterId = :cid")
    suspend fun revisionCountForChapter(cid: Long): Int
    @Query("SELECT COUNT(*) FROM revisions WHERE done = 0 AND dueDate <= :d")
    suspend fun dueRevisionCount(d: Long): Int

    // Focus sessions
    @Query("SELECT * FROM sessions ORDER BY startedAt DESC")
    fun sessions(): Flow<List<FocusSession>>
    @Insert suspend fun insertSession(s: FocusSession): Long
    @Query("DELETE FROM sessions") suspend fun wipeSessions()
    @Query("SELECT COALESCE(SUM(actualSec), 0) FROM sessions WHERE startedAt >= :from AND startedAt < :to")
    suspend fun focusSecondsBetween(from: Long, to: Long): Int

    // Timetable
    @Query("SELECT * FROM timetable ORDER BY dayOfWeek, startMin, id")
    fun timetable(): Flow<List<TimetableSlot>>
    @Insert suspend fun insertSlot(s: TimetableSlot): Long
    @Insert suspend fun insertSlots(s: List<TimetableSlot>)
    @Update suspend fun updateSlot(s: TimetableSlot)
    @Delete suspend fun deleteSlot(s: TimetableSlot)

    // Restore support
    @Query("DELETE FROM tasks") suspend fun wipeTasks()
    @Query("DELETE FROM revisions") suspend fun wipeRevisions()
    @Query("DELETE FROM chapters") suspend fun wipeChapters()
    @Query("DELETE FROM subjects") suspend fun wipeSubjects()
    @Query("DELETE FROM timetable") suspend fun wipeTimetable()
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putSubjects(l: List<Subject>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putChapters(l: List<Chapter>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putTasks(l: List<StudyTask>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putRevisions(l: List<RevisionItem>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putSessions(l: List<FocusSession>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putSlots(l: List<TimetableSlot>)
}

@Database(
    entities = [Subject::class, Chapter::class, StudyTask::class, RevisionItem::class, FocusSession::class, TimetableSlot::class],
    version = 1,
    exportSchema = false
)
abstract class BoomDatabase : RoomDatabase() {
    abstract fun dao(): BoomDao

    companion object {
        @Volatile private var instance: BoomDatabase? = null

        fun get(context: Context): BoomDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, BoomDatabase::class.java, "boom.db")
                .build().also { instance = it }
        }
    }
}
