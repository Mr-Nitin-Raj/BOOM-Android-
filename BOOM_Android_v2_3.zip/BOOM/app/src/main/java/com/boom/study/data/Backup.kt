package com.boom.study.data

import org.json.JSONArray
import org.json.JSONObject

class Snapshot(
    val subjects: List<Subject>,
    val chapters: List<Chapter>,
    val tasks: List<StudyTask>,
    val revisions: List<RevisionItem>,
    val sessions: List<FocusSession>,
    val slots: List<TimetableSlot>,
    val settings: Settings
)

/** Converts the whole local database + settings to/from a single JSON document. */
object BackupCodec {
    private const val FORMAT = 1

    private fun JSONObject.putNullable(key: String, v: Any?): JSONObject = put(key, v ?: JSONObject.NULL)
    private fun JSONObject.longOrNull(key: String): Long? = if (isNull(key)) null else getLong(key)
    private fun JSONObject.intOrNull(key: String): Int? = if (isNull(key)) null else getInt(key)
    private fun <T> JSONArray.mapObjects(f: (JSONObject) -> T): List<T> = (0 until length()).map { f(getJSONObject(it)) }

    fun encode(s: Snapshot): String {
        val root = JSONObject()
        root.put("app", "BOOM").put("format", FORMAT).put("exportedAt", System.currentTimeMillis())
        root.put("settings", s.settings.toJson())
        root.put("subjects", JSONArray(s.subjects.map {
            JSONObject().put("id", it.id).put("name", it.name).putNullable("parentGroup", it.parentGroup)
                .put("color", it.color).put("sortOrder", it.sortOrder).put("custom", it.custom)
        }))
        root.put("chapters", JSONArray(s.chapters.map {
            JSONObject().put("id", it.id).put("subjectId", it.subjectId).put("name", it.name)
                .put("status", it.status).put("sortOrder", it.sortOrder)
        }))
        root.put("tasks", JSONArray(s.tasks.map {
            JSONObject().put("id", it.id).put("title", it.title).putNullable("subjectId", it.subjectId)
                .putNullable("chapterId", it.chapterId).put("date", it.date).putNullable("startMin", it.startMin)
                .putNullable("endMin", it.endMin).put("priority", it.priority).put("done", it.done)
                .putNullable("completedAt", it.completedAt).put("rescheduled", it.rescheduled)
        }))
        root.put("revisions", JSONArray(s.revisions.map {
            JSONObject().put("id", it.id).put("subjectId", it.subjectId).putNullable("chapterId", it.chapterId)
                .put("type", it.type).put("dueDate", it.dueDate).put("done", it.done).putNullable("doneAt", it.doneAt)
        }))
        root.put("sessions", JSONArray(s.sessions.map {
            JSONObject().put("id", it.id).put("startedAt", it.startedAt).put("plannedSec", it.plannedSec)
                .put("actualSec", it.actualSec).put("completed", it.completed).putNullable("subjectId", it.subjectId)
        }))
        root.put("timetable", JSONArray(s.slots.map {
            JSONObject().put("id", it.id).put("dayOfWeek", it.dayOfWeek).put("startMin", it.startMin)
                .put("endMin", it.endMin).put("label", it.label).putNullable("subjectId", it.subjectId)
        }))
        return root.toString(2)
    }

    fun decode(json: String): Snapshot {
        val root = JSONObject(json)
        require(root.optString("app") == "BOOM") { "This file is not a BOOM backup." }
        require(root.optInt("format", 0) in 1..FORMAT) { "Unsupported backup version." }
        return Snapshot(
            subjects = root.getJSONArray("subjects").mapObjects {
                Subject(it.getLong("id"), it.getString("name"), if (it.isNull("parentGroup")) null else it.getString("parentGroup"),
                    it.getLong("color"), it.getInt("sortOrder"), it.getBoolean("custom"))
            },
            chapters = root.getJSONArray("chapters").mapObjects {
                Chapter(it.getLong("id"), it.getLong("subjectId"), it.getString("name"), it.getString("status"), it.getInt("sortOrder"))
            },
            tasks = root.getJSONArray("tasks").mapObjects {
                StudyTask(it.getLong("id"), it.getString("title"), it.longOrNull("subjectId"), it.longOrNull("chapterId"),
                    it.getLong("date"), it.intOrNull("startMin"), it.intOrNull("endMin"), it.getInt("priority"),
                    it.getBoolean("done"), it.longOrNull("completedAt"), it.getInt("rescheduled"))
            },
            revisions = root.getJSONArray("revisions").mapObjects {
                RevisionItem(it.getLong("id"), it.getLong("subjectId"), it.longOrNull("chapterId"), it.getString("type"),
                    it.getLong("dueDate"), it.getBoolean("done"), it.longOrNull("doneAt"))
            },
            sessions = root.getJSONArray("sessions").mapObjects {
                FocusSession(it.getLong("id"), it.getLong("startedAt"), it.getInt("plannedSec"), it.getInt("actualSec"),
                    it.getBoolean("completed"), it.longOrNull("subjectId"))
            },
            slots = root.getJSONArray("timetable").mapObjects {
                TimetableSlot(it.getLong("id"), it.getInt("dayOfWeek"), it.getInt("startMin"), it.getInt("endMin"),
                    it.getString("label"), it.longOrNull("subjectId"))
            },
            settings = Settings.fromJson(root.getJSONObject("settings"))
        )
    }
}
