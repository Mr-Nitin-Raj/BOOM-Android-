package com.boom.study.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.boom.study.viewmodel.Overview

class LevelInfo(val level: Int, val name: String, val xp: Int, val into: Int, val needed: Int)
class Badge(val title: String, val desc: String, val earned: Boolean, val icon: ImageVector)

private val levels = listOf(
    0 to "Rookie", 100 to "Grinder", 300 to "Sharpshooter", 600 to "Achiever",
    1000 to "Topper", 1600 to "Legend", 2500 to "BOOM Master"
)

/** XP: task +10, focus minute +1, completed chapter +25, finished revision +15. */
fun xpOf(o: Overview): Int = o.totalTasksDone * 10 + o.totalFocusMin + o.doneChapters * 25 + o.revisionDone * 15

fun levelOf(xp: Int): LevelInfo {
    var idx = 0
    levels.forEachIndexed { i, l -> if (xp >= l.first) idx = i }
    val cur = levels[idx].first
    val next = levels.getOrNull(idx + 1)?.first
    return LevelInfo(idx + 1, levels[idx].second, xp, xp - cur, if (next == null) 0 else next - cur)
}

fun badgesOf(o: Overview): List<Badge> = listOf(
    Badge("First step", "Complete a task", o.totalTasksDone >= 1, Icons.Default.Flag),
    Badge("On fire", "3-day streak", o.bestStreak >= 3, Icons.Default.LocalFireDepartment),
    Badge("Unstoppable", "7-day streak", o.bestStreak >= 7, Icons.Default.Bolt),
    Badge("Deep focus", "10 hours focused", o.totalFocusMin >= 600, Icons.Default.Timer),
    Badge("Centurion", "Finish 100 tasks", o.totalTasksDone >= 100, Icons.Default.EmojiEvents),
    Badge("Halfway there", "50% of syllabus", o.syllabusFraction >= 0.5f, Icons.Default.MenuBook),
    Badge("Reviser", "Finish 10 revisions", o.revisionDone >= 10, Icons.Default.Autorenew),
    Badge("Syllabus slayer", "100% of syllabus", o.totalChapters > 0 && o.syllabusFraction >= 1f, Icons.Default.Star)
)

@Composable
fun LevelCard(o: Overview) {
    val xp = xpOf(o)
    val li = levelOf(xp)
    BoomCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Text("${li.level}", fontWeight = FontWeight.Black, fontSize = 20.sp, color = MaterialTheme.colorScheme.onPrimary)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                SectionLabel("Level ${li.level}")
                Text(li.name, style = MaterialTheme.typography.titleLarge)
            }
            Text("$xp XP", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        BoomProgress(if (li.needed == 0) 1f else li.into.toFloat() / li.needed)
        Spacer(Modifier.height(6.dp))
        Text(
            if (li.needed == 0) "Top level reached. Keep it up." else "${li.needed - li.into} XP to the next level",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            "Task +10 · focus minute +1 · chapter +25 · revision +15",
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp), color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun BadgesCard(o: Overview) {
    val badges = badgesOf(o)
    BoomCard {
        Row {
            SectionLabel("Achievements", Modifier.weight(1f))
            Text("${badges.count { it.earned }}/${badges.size}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(10.dp))
        badges.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEach { BadgeTile(it, Modifier.weight(1f)) }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun BadgeTile(b: Badge, modifier: Modifier) {
    val on = b.earned
    Surface(
        modifier = modifier, shape = RoundedCornerShape(14.dp),
        color = if (on) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(b.icon, null, tint = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
            Spacer(Modifier.width(8.dp))
            Column {
                Text(b.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = if (on) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                Text(b.desc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
