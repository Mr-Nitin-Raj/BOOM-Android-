# BOOM — CBSE study planner (Android, Kotlin + Jetpack Compose)

Offline-first study planner: dashboard with countdown to 15 Feb 2027, subject/chapter tracker
(5 statuses), daily/weekly planner + editable timetable, focus timer (15/25/45/60/custom),
automatic revision scheduling, analytics, optional local reminders, themes, JSON backup/restore.
MVVM + Room + Navigation Compose. No login, **no INTERNET permission**.

## Status — please read
This project was written but **not compiled or run** (the build sandbox had no access to Google
Maven / Android SDK). Expect a few small compile errors on first build; they are quick to fix.

## Get the APK (pick one)
**A. Without a computer (GitHub Actions)**
1. Create a free GitHub account and a new repository; upload all files of this folder (keep `.github/`).
2. Open the *Actions* tab → *Build BOOM APK* → wait for the green tick (or fix the error it shows).
3. Open the run → download the `BOOM-apk` artifact → unzip → install `app-release.apk` on your phone
   (allow "install unknown apps").

**B. Android Studio**
1. Install Android Studio (JDK 17 is bundled), open this folder, let Gradle sync (SDK Platform 35).
2. Build > Build APK(s), or run `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`.

The release build is signed with the debug key so it installs directly; use your own keystore for Play Store.

## Where things are
- `data/` Room entities, DAO, seed data (`Seed.kt`), repository, backup JSON codec, settings
- `viewmodel/` all ViewModels (Tracker, Planner, Revision, Focus, Overview, Settings)
- `ui/` theme, components, one file per screen group, navigation
- `notify/` notification channels, 15-minute reminder worker, timer-end alarm

## Notes
- Preloaded chapters follow standard CBSE Class 10 books but are **not verified** against your school's
  current syllabus. Statuses come from the earlier starter: Science (Carbon = in progress, last 3 not started),
  Maths all done, History/Geography/Pol. Science/Economics as listed there. Chapters not in the earlier
  starter (Age of Industrialisation, Consumer Rights, all English and Hindi) start as Not Started.
  Edit anything in the Syllabus tab.
- Reminders run roughly every 15 min via WorkManager, so timing is approximate. Android 13+ asks for notification permission when you switch one on.
- Closing the app mid-timer: the timer survives (stored end time) and a notification fires at the end.
- Data is local only; `allowBackup` is off, so use Settings > Back up before reinstalling.

## v2.1 premium additions
XP and 7 levels (Rookie to BOOM Master), 8 achievement badges, weekly streak strip, exam-phase label
(Build / Practice / Revision sprint / Final stretch), animated countdown, daily boost lines,
confetti + haptics when a focus session finishes, pulsing timer ring, refined card borders.

## v2.2 colours
New default theme **Obsidian Gold** (near-black + champagne gold). Also: Royal Indigo (rose gold), Emerald Night,
and the original Midnight Plum / Deep Night / Champagne Cream. Change under Settings > Theme.

## v2.3 premium UI
Floating pill navigation (selected tab expands with its label), serif display type for headings and the countdown,
24dp cards with fine borders and a soft press effect, theme-tinted chips/selection/dialogs.
